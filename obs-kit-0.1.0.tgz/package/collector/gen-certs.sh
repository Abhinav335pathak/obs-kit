#!/usr/bin/env bash
# Generates a private CA plus server and client certificates for mTLS.
# Usage: ./gen-certs.sh [outdir]   (default ./certs)
set -euo pipefail
OUT="${1:-certs}"; mkdir -p "$OUT"; cd "$OUT"
DAYS="${CERT_DAYS:-365}"

# Private CA (keep ca.key offline in production)
openssl genrsa -out ca.key 4096 2>/dev/null
openssl req -x509 -new -key ca.key -sha256 -days 1825 -subj "/CN=obskit-private-ca" -out ca.crt

issue() { # name, CN, extKeyUsage, SANs
  local name="$1" cn="$2" eku="$3" san="$4"
  openssl genrsa -out "$name.key" 2048 2>/dev/null
  openssl req -new -key "$name.key" -subj "/CN=$cn" -out "$name.csr"
  printf "subjectAltName=%s\nextendedKeyUsage=%s\nbasicConstraints=CA:FALSE\nkeyUsage=digitalSignature,keyEncipherment\n" "$san" "$eku" > "$name.ext"
  openssl x509 -req -in "$name.csr" -CA ca.crt -CAkey ca.key -CAcreateserial -days "$DAYS" -sha256 -extfile "$name.ext" -out "$name.crt" 2>/dev/null
  rm -f "$name.csr" "$name.ext"
}

issue collector-server collector  serverAuth "DNS:collector,DNS:localhost,IP:127.0.0.1"
issue viewer-server    viewer     serverAuth "DNS:viewer,DNS:localhost,IP:127.0.0.1"
issue collector-client collector-to-viewer clientAuth "DNS:collector"
issue sdk-client       service-sdk clientAuth "DNS:sdk"   # one per service in production; revoke by re-issuing the CA chain

chmod 600 *.key
echo "Certificates written to $(pwd)"
ls -1
