'use strict';
const path = require('path');
const fs = require('fs');

const PRESETS = {
  'http-api': { enable: ['http', 'express', 'fastify', 'koa', 'nestjs-core', 'hapi', 'pg', 'mysql', 'mysql2', 'mongodb', 'redis', 'ioredis', 'undici', 'graphql'] },
  grpc: { enable: ['grpc', 'http', 'pg', 'mysql2', 'redis', 'ioredis', 'undici'] },
  worker: { enable: ['http', 'pg', 'mysql', 'mysql2', 'mongodb', 'redis', 'ioredis', 'undici', 'aws-sdk'] },
  'queue-consumer': { enable: ['kafkajs', 'amqplib', 'aws-sdk', 'http', 'pg', 'mysql2', 'redis', 'ioredis', 'undici'] },
  generic: { enable: null }, // everything the auto bundle offers (minus noisy ones below)
};
const ALWAYS_OFF = ['fs', 'dns', 'net'];

function detectServiceType(cwd = process.cwd()) {
  let deps = {};
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf8'));
    deps = { ...pkg.dependencies, ...pkg.devDependencies };
  } catch { return 'generic'; }
  const has = (...n) => n.some((x) => x in deps);
  if (has('@grpc/grpc-js')) return 'grpc';
  const web = has('express', 'fastify', 'koa', '@nestjs/core', 'hapi', '@hapi/hapi', 'next', 'restify');
  if (has('kafkajs', 'amqplib', 'bullmq', 'bull')) return web ? 'http-api' : 'queue-consumer';
  if (web) return 'http-api';
  return 'generic';
}

function instrumentationConfig(type) {
  const cfg = {};
  for (const n of ALWAYS_OFF) cfg[`@opentelemetry/instrumentation-${n}`] = { enabled: false };
  const preset = PRESETS[type] || PRESETS.generic;
  if (!preset.enable) return cfg;
  const known = ['http','express','fastify','koa','nestjs-core','hapi','pg','mysql','mysql2','mongodb','redis','ioredis','undici','grpc','kafkajs','amqplib','aws-sdk','graphql','knex','generic-pool','winston','pino','bunyan'];
  for (const n of known) cfg[`@opentelemetry/instrumentation-${n}`] = { enabled: preset.enable.includes(n) || ['winston', 'pino', 'bunyan'].includes(n) };
  return cfg;
}

module.exports = { PRESETS, detectServiceType, instrumentationConfig };
