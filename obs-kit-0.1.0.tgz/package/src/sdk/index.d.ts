export interface ObsOptions {
  serviceName?: string;
  /** 'auto' (default) inspects package.json to pick an instrumentation preset. */
  serviceType?: 'auto' | 'http-api' | 'grpc' | 'worker' | 'queue-consumer' | 'generic';
  environment?: string;
  version?: string;
  /** Base URL of the viewer or collector OTLP/HTTP receiver. Default http://127.0.0.1:4320 */
  endpoint?: string;
  /** Bearer token sent with every export. */
  token?: string;
  /** 0..1, applied to new root traces only. Default 1. */
  sampleRate?: number;
  /** Extra attribute-name fragments to mask, on top of the defaults. */
  redactKeys?: string[];
  /** Forward console.* output as correlated logs. Default true. */
  captureConsole?: boolean;
  /** Emit process memory / CPU / event-loop metrics. Default true. */
  runtimeMetrics?: boolean;
  metricIntervalMs?: number;
  debug?: boolean;
  tls?: { caFile?: string; certFile?: string; keyFile?: string };
}
export function initObservability(opts?: ObsOptions): unknown;
export function flushObservability(): Promise<void>;
export function shutdownObservability(): Promise<void>;
export function resolveConfig(opts?: ObsOptions): Required<Pick<ObsOptions, 'serviceName' | 'endpoint'>> & Record<string, unknown>;
export function detectServiceType(cwd?: string): string;
