'use strict';
// Scrubs secrets before telemetry leaves the process.
// Works on COPIES: finished spans/log records may be frozen or getter-backed,
// so in-place mutation can silently fail and leak. We shadow the fields instead.

const DEFAULT_KEYS = [
  'password', 'passwd', 'secret', 'token', 'authorization', 'cookie',
  'set-cookie', 'api_key', 'apikey', 'api-key', 'card_number', 'cvv', 'ssn', 'private_key',
];
const VALUE_PATTERNS = [
  [/\bBearer\s+[A-Za-z0-9._~+\/-]+=*/gi, '[REDACTED]'],
  [/\b\d{4}[ -]?\d{4}[ -]?\d{4}[ -]?\d{4}\b/g, '[REDACTED]'],
  [/eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]*/g, '[REDACTED]'],
  // secrets in URLs / query strings
  [/([?&](?:token|access_token|api_key|apikey|key|password|secret|sig|signature)=)[^&\s#]+/gi, '$1[REDACTED]'],
  // user:pass@host
  [/(\/\/[^\/\s:@]+:)[^@\s\/]+@/g, '$1[REDACTED]@'],
];
const MASK = '[REDACTED]';

function makeRedactor(extraKeys = []) {
  const keys = [...DEFAULT_KEYS, ...extraKeys].map((k) => String(k).toLowerCase());
  const sensitive = (k) => { const lk = String(k).toLowerCase(); return keys.some((s) => lk.includes(s)); };
  const scrubString = (s) => VALUE_PATTERNS.reduce((acc, [re, rep]) => acc.replace(re, rep), s);
  const scrubValue = (v) => (typeof v === 'string' ? scrubString(v) : Array.isArray(v) ? v.map(scrubValue) : v);

  /** Returns a NEW attribute object; never mutates the input. */
  function scrubAttributes(attrs) {
    if (!attrs || typeof attrs !== 'object') return attrs;
    const out = {};
    for (const k of Object.keys(attrs)) out[k] = sensitive(k) ? MASK : scrubValue(attrs[k]);
    return out;
  }
  return { scrubAttributes, scrubString, MASK };
}

// Shadow selected fields on a derived object whose prototype is the original,
// so every getter/method the exporter relies on keeps working.
function shadow(item, fields) {
  const props = {};
  for (const [k, v] of Object.entries(fields)) props[k] = { value: v, enumerable: true, configurable: true, writable: true };
  return Object.create(item, props);
}

function redactSpan(span, r) {
  const f = { attributes: r.scrubAttributes(span.attributes) };
  if (Array.isArray(span.events)) f.events = span.events.map((e) => ({ ...e, name: typeof e.name === 'string' ? r.scrubString(e.name) : e.name, attributes: r.scrubAttributes(e.attributes) }));
  if (span.status && typeof span.status.message === 'string') f.status = { ...span.status, message: r.scrubString(span.status.message) };
  return shadow(span, f);
}
function redactLog(rec, r) {
  const f = { attributes: r.scrubAttributes(rec.attributes) };
  if (typeof rec.body === 'string') f.body = r.scrubString(rec.body);
  return shadow(rec, f);
}

function redactingExporter(inner, redactor, kind) {
  const fn = kind === 'logs' ? redactLog : redactSpan;
  return {
    export(items, cb) { return inner.export(items.map((it) => fn(it, redactor)), cb); },
    shutdown: () => inner.shutdown(),
    forceFlush: () => (inner.forceFlush ? inner.forceFlush() : Promise.resolve()),
  };
}

module.exports = { makeRedactor, redactingExporter, redactSpan, redactLog, DEFAULT_KEYS, MASK };
