// Optional: lets OpenTelemetry patch ES-module imports (Node >= 20.6).
// `obs-kit start` adds `--import` for this file when import-in-the-middle can be resolved.
import { register } from 'node:module';
try { register('import-in-the-middle/hook.mjs', import.meta.url); } catch { /* instrumentation of ESM imports unavailable */ }
