'use strict';
// Zero-code usage:   node -r obs-kit/register app.js     (configure with OBS_* env vars)
// `obs-kit start` injects this via NODE_OPTIONS so no code change is needed at all.
//
// Skip package-manager processes: with NODE_OPTIONS set, `npm start` would otherwise
// instrument npm itself and report its own noise as your service.
const entry = String(process.argv[1] || '');
const isPackageManager = /(^|[\\/])(npm|npx|yarn|yarnpkg|pnpm|pnpx|corepack|bun)(-cli)?(\.c?js|\.mjs)?$/.test(entry) ||
  /node_modules[\\/](npm|pnpm|yarn)[\\/]/.test(entry) || /[\\/]corepack[\\/]/.test(entry);
if (!isPackageManager) require('./index').initObservability();
