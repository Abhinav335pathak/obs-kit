'use strict';
/**
 * obs-kit SDK: one call (or `node -r obs-kit/register`) wires OpenTelemetry
 * traces + metrics + logs to an obs-kit viewer / OTel collector.
 *
 * Providers are built explicitly (not via NodeSDK) so that option-name changes
 * between OpenTelemetry releases cannot silently drop a signal. Supported
 * lines: sdk-trace/metrics/resources 2.x, sdk-logs/exporters/instrumentation 0.2xx.
 * Telemetry must never break the host app: every failure degrades to a warning.
 */
const fs = require('fs');
const util = require('util');
const { makeRedactor, redactingExporter } = require('./redact');
const { detectServiceType, instrumentationConfig } = require('./presets');

const state = { started: false, providers: null, config: null, flushing: null };

const warn = (m) => { try { process.stderr.write(`[obs-kit] ${m}\n`); } catch { /* ignore */ } };
const envv = (n, d) => { const v = process.env[n]; return v === undefined || v === '' ? d : v; };
const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };

function resolveConfig(opts = {}) {
  const e = process.env;
  const csv = (s) => String(s).split(',').map((x) => x.trim()).filter(Boolean);
  return {
    serviceName: opts.serviceName || envv('OBS_SERVICE_NAME', envv('OTEL_SERVICE_NAME', envv('npm_package_name', 'unknown-service'))),
    serviceType: opts.serviceType || envv('OBS_SERVICE_TYPE', 'auto'),
    environment: opts.environment || envv('OBS_ENVIRONMENT', e.NODE_ENV || 'development'),
    version: opts.version || envv('OBS_SERVICE_VERSION', envv('npm_package_version', '')),
    endpoint: String(opts.endpoint || envv('OBS_ENDPOINT', envv('OTEL_EXPORTER_OTLP_ENDPOINT', 'http://127.0.0.1:4320'))).replace(/\/$/, ''),
    token: opts.token || envv('OBS_TOKEN', ''),
    sampleRate: num(opts.sampleRate ?? envv('OBS_SAMPLE_RATE', '1'), 1),
    redactKeys: opts.redactKeys || csv(envv('OBS_REDACT_KEYS', '')),
    captureConsole: opts.captureConsole ?? envv('OBS_CAPTURE_CONSOLE', 'true') !== 'false',
    runtimeMetrics: opts.runtimeMetrics ?? envv('OBS_RUNTIME_METRICS', 'true') !== 'false',
    metricIntervalMs: num(opts.metricIntervalMs ?? envv('OBS_METRIC_INTERVAL_MS', '10000'), 10000),
    debug: opts.debug ?? envv('OBS_DEBUG', '') === '1',
    tls: {
      ca: opts.tls?.caFile || envv('OBS_CA_FILE', ''),
      cert: opts.tls?.certFile || envv('OBS_CERT_FILE', ''),
      key: opts.tls?.keyFile || envv('OBS_KEY_FILE', ''),
    },
  };
}

function exporterOptions(cfg, signal) {
  const o = { url: `${cfg.endpoint}/v1/${signal}`, headers: {}, timeoutMillis: 10000 };
  if (cfg.token) o.headers.Authorization = `Bearer ${cfg.token}`;
  if (cfg.tls.ca || cfg.tls.cert) {
    const agent = {
      ca: cfg.tls.ca ? fs.readFileSync(cfg.tls.ca) : undefined,
      cert: cfg.tls.cert ? fs.readFileSync(cfg.tls.cert) : undefined,
      key: cfg.tls.key ? fs.readFileSync(cfg.tls.key) : undefined,
      rejectUnauthorized: true,
    };
    o.httpAgentOptions = agent; // option name differs across 0.2xx releases: set both
    o.agentOptions = agent;
  }
  return o;
}

function need(name) {
  try { return require(name); } catch (e) {
    const err = new Error(`missing or broken dependency "${name}" (${e.message.split('\n')[0]}). Run: npm install obs-kit`);
    err.code = 'OBS_DEP'; throw err;
  }
}

function makeResource(Resources, attrs) {
  if (typeof Resources.resourceFromAttributes === 'function') return Resources.resourceFromAttributes(attrs); // 2.x
  if (typeof Resources.Resource === 'function') return new Resources.Resource(attrs); // 1.x
  throw new Error('unsupported @opentelemetry/resources version');
}

function bridgeConsole(logsApi) {
  if (console.__obsBridged) return;
  const logger = logsApi.logs.getLogger('obs-kit.console');
  const S = logsApi.SeverityNumber;
  const map = { log: ['INFO', S.INFO], info: ['INFO', S.INFO], warn: ['WARN', S.WARN], error: ['ERROR', S.ERROR], debug: ['DEBUG', S.DEBUG] };
  for (const [method, [text, sev]] of Object.entries(map)) {
    const orig = console[method].bind(console);
    console[method] = (...args) => {
      orig(...args);
      try {
        const body = args.map((a) => (typeof a === 'string' ? a : util.inspect(a, { depth: 3 }))).join(' ').slice(0, 8192);
        logger.emit({ severityText: text, severityNumber: sev, body }); // active span context is attached automatically
      } catch { /* telemetry must never break the app */ }
    };
  }
  Object.defineProperty(console, '__obsBridged', { value: true });
}

function startRuntimeMetrics(metricsApi, cfg) {
  const meter = metricsApi.metrics.getMeter('obs-kit.runtime');
  const gauge = (name, unit, desc, read) => meter.createObservableGauge(name, { unit, description: desc }).addCallback((r) => { try { r.observe(read()); } catch { /* ignore */ } });
  gauge('obs_kit.sdk.up', '1', 'SDK heartbeat (always 1 while the process exports)', () => 1);
  gauge('process.uptime', 's', 'Process uptime', () => process.uptime());
  gauge('process.memory.rss', 'By', 'Resident set size', () => process.memoryUsage().rss);
  gauge('process.memory.heap_used', 'By', 'V8 heap used', () => process.memoryUsage().heapUsed);
  gauge('process.memory.heap_total', 'By', 'V8 heap total', () => process.memoryUsage().heapTotal);
  let lastCpu = process.cpuUsage(); let lastT = process.hrtime.bigint();
  gauge('process.cpu.utilization', '1', 'CPU time / wall time since last read (1 = one full core)', () => {
    const now = process.hrtime.bigint(); const u = process.cpuUsage(lastCpu); const us = Number(now - lastT) / 1000;
    lastCpu = process.cpuUsage(); lastT = now; return us > 0 ? (u.user + u.system) / us : 0;
  });
  try {
    const { monitorEventLoopDelay } = require('perf_hooks');
    const h = monitorEventLoopDelay({ resolution: 20 }); h.enable();
    gauge('nodejs.eventloop.delay.p99', 'ms', 'Event-loop delay p99 since last read', () => { const v = h.percentile(99) / 1e6; h.reset(); return Number.isFinite(v) ? v : 0; });
  } catch { /* older runtimes */ }
  gauge('nodejs.active_handles', '1', 'Active libuv handles', () => (process._getActiveHandles ? process._getActiveHandles().length : 0));
}

function initObservability(opts = {}) {
  if (state.started) return state.providers;
  if (envv('OBS_DISABLED', '') === 'true') return null;
  try {
    const cfg = resolveConfig(opts);
    if (cfg.serviceType === 'auto') cfg.serviceType = detectServiceType();
    if (cfg.debug) { try { const api = need('@opentelemetry/api'); api.diag.setLogger(new api.DiagConsoleLogger(), api.DiagLogLevel.WARN); } catch { /* ignore */ } }

    const api = need('@opentelemetry/api');
    const logsApi = need('@opentelemetry/api-logs');
    const Resources = need('@opentelemetry/resources');
    const { NodeTracerProvider } = need('@opentelemetry/sdk-trace-node');
    const { BatchSpanProcessor, ParentBasedSampler, TraceIdRatioBasedSampler } = need('@opentelemetry/sdk-trace-base');
    const { MeterProvider, PeriodicExportingMetricReader } = need('@opentelemetry/sdk-metrics');
    const { LoggerProvider, BatchLogRecordProcessor } = need('@opentelemetry/sdk-logs');
    const { OTLPTraceExporter } = need('@opentelemetry/exporter-trace-otlp-http');
    const { OTLPMetricExporter } = need('@opentelemetry/exporter-metrics-otlp-http');
    const { OTLPLogExporter } = need('@opentelemetry/exporter-logs-otlp-http');
    const { registerInstrumentations } = need('@opentelemetry/instrumentation');
    const { getNodeAutoInstrumentations } = need('@opentelemetry/auto-instrumentations-node');

    const redactor = makeRedactor(cfg.redactKeys);
    const resource = makeResource(Resources, {
      'service.name': cfg.serviceName,
      'service.type': cfg.serviceType,
      'deployment.environment.name': cfg.environment,
      ...(cfg.version ? { 'service.version': cfg.version } : {}),
      'process.pid': process.pid,
      'telemetry.distro.name': 'obs-kit',
    });

    // Logs first so log-library instrumentations can find the global provider.
    const lp = new LoggerProvider({
      resource,
      processors: [new BatchLogRecordProcessor(
        redactingExporter(new OTLPLogExporter(exporterOptions(cfg, 'logs')), redactor, 'logs'),
        { scheduledDelayMillis: 1000, maxQueueSize: 4096 })],
    });
    logsApi.logs.setGlobalLoggerProvider(lp);

    const reader = new PeriodicExportingMetricReader({
      exporter: new OTLPMetricExporter(exporterOptions(cfg, 'metrics')),
      exportIntervalMillis: cfg.metricIntervalMs,
      exportTimeoutMillis: Math.min(10000, cfg.metricIntervalMs),
    });
    const mp = new MeterProvider({ resource, readers: [reader] });
    api.metrics.setGlobalMeterProvider(mp);

    const sampler = new ParentBasedSampler({ root: new TraceIdRatioBasedSampler(Math.min(Math.max(cfg.sampleRate, 0), 1)) });
    const tp = new NodeTracerProvider({
      resource, sampler,
      spanProcessors: [new BatchSpanProcessor(
        redactingExporter(new OTLPTraceExporter(exporterOptions(cfg, 'traces')), redactor, 'spans'),
        { scheduledDelayMillis: 1000, maxExportBatchSize: 512, maxQueueSize: 4096 })],
    });
    tp.register(); // global tracer provider + async context manager + W3C propagation

    registerInstrumentations({ instrumentations: [getNodeAutoInstrumentations(instrumentationConfig(cfg.serviceType))] });

    if (cfg.runtimeMetrics) startRuntimeMetrics(api, cfg);
    if (cfg.captureConsole) bridgeConsole(logsApi);

    state.started = true; state.config = cfg; state.providers = { tp, mp, lp };
    installShutdownHooks();
    // Don't make a lone, quiet service wait a full interval for its first data point.
    setTimeout(() => { mp.forceFlush().catch(() => {}); }, 2000).unref();
    if (cfg.debug) warn(`started: ${cfg.serviceName} (${cfg.serviceType}) -> ${cfg.endpoint}`);
    return state.providers;
  } catch (e) {
    warn(`telemetry disabled: ${e.message}`);
    return null;
  }
}

async function flushObservability() {
  const p = state.providers; if (!p) return;
  if (!state.flushing) {
    state.flushing = Promise.allSettled([p.tp.forceFlush(), p.mp.forceFlush(), p.lp.forceFlush()]).finally(() => { state.flushing = null; });
  }
  await state.flushing;
}

async function shutdownObservability() {
  const p = state.providers; if (!p) return;
  state.providers = null; state.started = false;
  await Promise.allSettled([p.tp.shutdown(), p.mp.shutdown(), p.lp.shutdown()]);
}

function installShutdownHooks() {
  process.on('beforeExit', () => { flushObservability().catch(() => {}); });
  for (const sig of ['SIGINT', 'SIGTERM']) {
    const handler = () => {
      // If the app has its own handler it owns shutdown; we just flush in the background.
      const ours = process.listenerCount(sig) === 1;
      const done = Promise.race([shutdownObservability(), new Promise((r) => setTimeout(r, 2500).unref())]);
      if (ours) done.finally(() => { process.removeListener(sig, handler); process.kill(process.pid, sig); });
    };
    process.on(sig, handler);
  }
}

module.exports = { initObservability, flushObservability, shutdownObservability, resolveConfig, detectServiceType };
