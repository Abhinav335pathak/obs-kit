'use strict';
// Minimal, dependency-free decoder for OTLP/HTTP *protobuf* payloads, producing the
// same object shape as OTLP/JSON so otlp.js can parse both. This is what lets
// Python / Java / .NET / Go exporters (which default to protobuf) talk to the viewer directly.
// Field numbers follow opentelemetry/proto/{common,resource,trace,logs,metrics}/v1.
// Bounded: depth, field count and total size are capped because input is untrusted.

const MAX_DEPTH = 12;

class Reader {
  constructor(buf, start = 0, end = buf.length) { this.b = buf; this.p = start; this.e = end; }
  more() { return this.p < this.e; }
  varint() { // returns BigInt-safe Number for <= 2^53, else BigInt string via big()
    let shift = 0n, v = 0n;
    for (let i = 0; i < 10; i++) {
      if (this.p >= this.e) throw new Error('truncated varint');
      const byte = this.b[this.p++];
      v |= BigInt(byte & 0x7f) << shift; shift += 7n;
      if (!(byte & 0x80)) return v;
    }
    throw new Error('varint too long');
  }
  tag() { const t = Number(this.varint()); return [t >>> 3, t & 7]; }
  bytes() {
    const n = Number(this.varint());
    if (n < 0 || this.p + n > this.e) throw new Error('truncated field');
    const s = this.p; this.p += n; return [s, s + n];
  }
  fixed64() { if (this.p + 8 > this.e) throw new Error('truncated'); const v = this.b.readBigUInt64LE(this.p); this.p += 8; return v; }
  fixed32() { if (this.p + 4 > this.e) throw new Error('truncated'); const v = this.b.readUInt32LE(this.p); this.p += 4; return v; }
  skip(wt) {
    if (wt === 0) this.varint(); else if (wt === 1) this.p += 8; else if (wt === 5) this.p += 4;
    else if (wt === 2) this.bytes(); else throw new Error('unsupported wire type ' + wt);
  }
}
const sub = (r) => { const [s, e] = r.bytes(); return new Reader(r.b, s, e); };
const str = (r) => { const [s, e] = r.bytes(); return r.b.toString('utf8', s, e); };
const hex = (r) => { const [s, e] = r.bytes(); return r.b.toString('hex', s, e); };
const f64 = (v) => { const b = Buffer.alloc(8); b.writeBigUInt64LE(v); return b.readDoubleLE(0); };
const s64 = (v) => BigInt.asIntN(64, v);

function each(r, fn, depth) {
  if (depth > MAX_DEPTH) throw new Error('nesting too deep');
  let n = 0;
  while (r.more()) {
    if (++n > 200000) throw new Error('too many fields');
    const [f, wt] = r.tag(); fn(f, wt, r);
  }
}
function list(r, f, wt, arr, parse, depth) { if (wt !== 2) return r.skip(wt); arr.push(parse(sub(r), depth + 1)); }

function anyValue(r, depth) {
  const v = {};
  each(r, (f, wt, rd) => {
    if (f === 1 && wt === 2) v.stringValue = str(rd);
    else if (f === 2 && wt === 0) v.boolValue = rd.varint() !== 0n;
    else if (f === 3 && wt === 0) v.intValue = String(s64(rd.varint()));
    else if (f === 4 && wt === 1) v.doubleValue = f64(rd.fixed64());
    else if (f === 5 && wt === 2) { const vals = []; each(sub(rd), (ff, w2, r2) => (ff === 1 ? list(r2, ff, w2, vals, anyValue, depth + 1) : r2.skip(w2)), depth + 1); v.arrayValue = { values: vals }; }
    else if (f === 6 && wt === 2) { const vals = []; each(sub(rd), (ff, w2, r2) => (ff === 1 ? list(r2, ff, w2, vals, keyValue, depth + 1) : r2.skip(w2)), depth + 1); v.kvlistValue = { values: vals }; }
    else if (f === 7 && wt === 2) v.bytesValue = hex(rd);
    else rd.skip(wt);
  }, depth);
  return v;
}
function keyValue(r, depth) {
  const kv = {};
  each(r, (f, wt, rd) => { if (f === 1 && wt === 2) kv.key = str(rd); else if (f === 2 && wt === 2) kv.value = anyValue(sub(rd), depth + 1); else rd.skip(wt); }, depth);
  return kv;
}
const resource = (r, depth) => { const o = { attributes: [] }; each(r, (f, wt, rd) => (f === 1 ? list(rd, f, wt, o.attributes, keyValue, depth) : rd.skip(wt)), depth); return o; };

function status(r, depth) { const o = {}; each(r, (f, wt, rd) => { if (f === 2 && wt === 2) o.message = str(rd); else if (f === 3 && wt === 0) o.code = Number(rd.varint()); else rd.skip(wt); }, depth); return o; }
function span(r, depth) {
  const s = { attributes: [] };
  each(r, (f, wt, rd) => {
    if (f === 1 && wt === 2) s.traceId = hex(rd); else if (f === 2 && wt === 2) s.spanId = hex(rd); else if (f === 4 && wt === 2) s.parentSpanId = hex(rd);
    else if (f === 5 && wt === 2) s.name = str(rd); else if (f === 6 && wt === 0) s.kind = Number(rd.varint());
    else if (f === 7 && wt === 1) s.startTimeUnixNano = String(rd.fixed64()); else if (f === 8 && wt === 1) s.endTimeUnixNano = String(rd.fixed64());
    else if (f === 9) list(rd, f, wt, s.attributes, keyValue, depth); else if (f === 15 && wt === 2) s.status = status(sub(rd), depth + 1);
    else rd.skip(wt);
  }, depth);
  return s;
}
function logRecord(r, depth) {
  const l = { attributes: [] };
  each(r, (f, wt, rd) => {
    if (f === 1 && wt === 1) l.timeUnixNano = String(rd.fixed64()); else if (f === 11 && wt === 1) l.observedTimeUnixNano = String(rd.fixed64());
    else if (f === 2 && wt === 0) l.severityNumber = Number(rd.varint()); else if (f === 3 && wt === 2) l.severityText = str(rd);
    else if (f === 5 && wt === 2) l.body = anyValue(sub(rd), depth + 1); else if (f === 6) list(rd, f, wt, l.attributes, keyValue, depth);
    else if (f === 9 && wt === 2) l.traceId = hex(rd); else if (f === 10 && wt === 2) l.spanId = hex(rd); else rd.skip(wt);
  }, depth);
  return l;
}
function packed(r, wt, kind) { // repeated fixed64 / double, packed (wt 2) or not
  if (wt === 2) { const sr = sub(r); const out = []; while (sr.more()) out.push(kind === 'd' ? f64(sr.fixed64()) : Number(sr.fixed64())); return out; }
  return [kind === 'd' ? f64(r.fixed64()) : Number(r.fixed64())];
}
function numberDP(r, depth) {
  const d = { attributes: [] };
  each(r, (f, wt, rd) => {
    if (f === 7) list(rd, f, wt, d.attributes, keyValue, depth); else if (f === 3 && wt === 1) d.timeUnixNano = String(rd.fixed64());
    else if (f === 4 && wt === 1) d.asDouble = f64(rd.fixed64()); else if (f === 6 && wt === 1) d.asInt = String(s64(rd.fixed64())); else rd.skip(wt);
  }, depth);
  return d;
}
function histDP(r, depth) {
  const d = { attributes: [], bucketCounts: [], explicitBounds: [] };
  each(r, (f, wt, rd) => {
    if (f === 9) list(rd, f, wt, d.attributes, keyValue, depth); else if (f === 3 && wt === 1) d.timeUnixNano = String(rd.fixed64());
    else if (f === 4 && wt === 1) d.count = String(rd.fixed64()); else if (f === 5 && wt === 1) d.sum = f64(rd.fixed64());
    else if (f === 6) d.bucketCounts.push(...packed(rd, wt, 'u')); else if (f === 7) d.explicitBounds.push(...packed(rd, wt, 'd')); else rd.skip(wt);
  }, depth);
  return d;
}
function expHistDP(r, depth) { // only count/sum are used by the viewer
  const d = { attributes: [] };
  each(r, (f, wt, rd) => {
    if (f === 1) list(rd, f, wt, d.attributes, keyValue, depth); else if (f === 3 && wt === 1) d.timeUnixNano = String(rd.fixed64());
    else if (f === 4 && wt === 1) d.count = String(rd.fixed64()); else if (f === 5 && wt === 1) d.sum = f64(rd.fixed64()); else rd.skip(wt);
  }, depth);
  return d;
}
function dataBlock(dp, extra) {
  return (r, depth) => {
    const o = { dataPoints: [] };
    each(r, (f, wt, rd) => {
      if (f === 1) list(rd, f, wt, o.dataPoints, dp, depth);
      else if (f === 2 && wt === 0 && extra) o.aggregationTemporality = Number(rd.varint());
      else if (f === 3 && wt === 0 && extra) o.isMonotonic = rd.varint() !== 0n; else rd.skip(wt);
    }, depth);
    return o;
  };
}
const gaugeB = dataBlock(numberDP, false), sumB = dataBlock(numberDP, true), histB = dataBlock(histDP, true), expB = dataBlock(expHistDP, true);
function metric(r, depth) {
  const m = {};
  each(r, (f, wt, rd) => {
    if (f === 1 && wt === 2) m.name = str(rd); else if (f === 2 && wt === 2) m.description = str(rd); else if (f === 3 && wt === 2) m.unit = str(rd);
    else if (f === 5 && wt === 2) m.gauge = gaugeB(sub(rd), depth + 1); else if (f === 7 && wt === 2) m.sum = sumB(sub(rd), depth + 1);
    else if (f === 9 && wt === 2) m.histogram = histB(sub(rd), depth + 1); else if (f === 10 && wt === 2) m.exponentialHistogram = expB(sub(rd), depth + 1);
    else rd.skip(wt);
  }, depth);
  return m;
}

// Generic "Resource{N}s -> Scope{N}s -> items" envelope shared by all three signals.
function envelope(resKey, scopeKey, itemKey, itemFn) {
  return (buf) => {
    const out = { [resKey]: [] };
    each(new Reader(buf), (f, wt, rd) => {
      if (f !== 1 || wt !== 2) return rd.skip(wt);
      const rr = sub(rd); const entry = { [scopeKey]: [] };
      each(rr, (f2, w2, r2) => {
        if (f2 === 1 && w2 === 2) entry.resource = resource(sub(r2), 2);
        else if (f2 === 2 && w2 === 2) {
          const scope = { [itemKey]: [] };
          // ScopeSpans.spans, ScopeLogs.log_records and ScopeMetrics.metrics are all field 2
          each(sub(r2), (f3, w3, r3) => (f3 === 2 ? list(r3, f3, w3, scope[itemKey], itemFn, 3) : r3.skip(w3)), 2);
          entry[scopeKey].push(scope);
        } else r2.skip(w2);
      }, 1);
      out[resKey].push(entry);
    }, 0);
    return out;
  };
}
const decodeTraces = envelope('resourceSpans', 'scopeSpans', 'spans', span);
const decodeLogs = envelope('resourceLogs', 'scopeLogs', 'logRecords', logRecord);
const decodeMetrics = envelope('resourceMetrics', 'scopeMetrics', 'metrics', metric);

module.exports = { decodeTraces, decodeLogs, decodeMetrics };
