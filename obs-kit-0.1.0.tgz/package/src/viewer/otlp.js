'use strict';
// Flattens OTLP JSON payloads into simple records. Telemetry is untrusted input:
// everything is coerced and length-capped here.
const cap = (s, n = 2048) => (typeof s === 'string' && s.length > n ? s.slice(0, n) : s);

function anyValue(v) {
  if (!v || typeof v !== 'object') return null;
  if ('stringValue' in v) return cap(String(v.stringValue));
  if ('intValue' in v) return Number(v.intValue);
  if ('doubleValue' in v) return Number(v.doubleValue);
  if ('boolValue' in v) return Boolean(v.boolValue);
  if (v.arrayValue) return (v.arrayValue.values || []).slice(0, 50).map(anyValue);
  if (v.kvlistValue) return JSON.stringify(attrs(v.kvlistValue.values)).slice(0, 2048);
  if ('bytesValue' in v) return cap(String(v.bytesValue), 256);
  return null;
}
function attrs(list) {
  const o = {};
  for (const a of (list || []).slice(0, 100)) if (a && typeof a.key === 'string') o[cap(a.key, 200)] = anyValue(a.value);
  return o;
}
const big = (n) => { try { return BigInt(n || 0); } catch { try { return BigInt(Math.round(Number(n) || 0)); } catch { return 0n; } } };
const nanoToMs = (n) => Number(big(n) / 1000000n);
const durMs = (a, b) => Number(big(b) - big(a)) / 1e6;
const svc = (res) => cap(String(attrs(res?.attributes)['service.name'] || 'unknown'), 100);

function parseTraces(body) {
  const spans = [];
  for (const rs of body.resourceSpans || []) {
    const ra = attrs(rs.resource?.attributes); const service = svc(rs.resource);
    for (const ss of rs.scopeSpans || []) for (const s of ss.spans || []) {
      spans.push({
        traceId: cap(String(s.traceId), 64), spanId: cap(String(s.spanId), 32),
        parentSpanId: s.parentSpanId ? cap(String(s.parentSpanId), 32) : null,
        name: cap(String(s.name || ''), 300), service, kind: Number(s.kind) || 0,
        start: nanoToMs(s.startTimeUnixNano), durationMs: Math.max(0, durMs(s.startTimeUnixNano, s.endTimeUnixNano)),
        error: Number(s.status?.code) === 2, statusMessage: cap(String(s.status?.message || ''), 500),
        attributes: attrs(s.attributes), serviceType: ra['service.type'] || null,
        host: ra['host.name'] || null, pid: ra['process.pid'] ?? null,
      });
    }
  }
  return spans;
}

function parseLogs(body) {
  const out = [];
  for (const rl of body.resourceLogs || []) {
    const service = svc(rl.resource);
    for (const sl of rl.scopeLogs || []) for (const r of sl.logRecords || []) {
      const sevNum = Number(r.severityNumber) || 0;
      const sev = r.severityText || (sevNum >= 21 ? 'FATAL' : sevNum >= 17 ? 'ERROR' : sevNum >= 13 ? 'WARN' : sevNum >= 9 ? 'INFO' : sevNum >= 5 ? 'DEBUG' : sevNum >= 1 ? 'TRACE' : 'INFO');
      out.push({
        time: nanoToMs(r.timeUnixNano || r.observedTimeUnixNano) || Date.now(), service,
        severity: cap(String(sev).toUpperCase(), 20), body: cap(String(anyValue(r.body) ?? ''), 8192),
        traceId: r.traceId ? cap(String(r.traceId), 64) : null, spanId: r.spanId ? cap(String(r.spanId), 32) : null,
        attributes: attrs(r.attributes),
      });
    }
  }
  return out;
}

const numArr = (a) => (Array.isArray(a) ? a.slice(0, 200).map(Number) : []);

function parseMetrics(body) {
  const out = [];
  for (const rm of body.resourceMetrics || []) {
    const service = svc(rm.resource);
    for (const sm of rm.scopeMetrics || []) for (const m of sm.metrics || []) {
      const kind = m.sum ? 'sum' : m.gauge ? 'gauge' : m.histogram ? 'histogram' : m.exponentialHistogram ? 'exphistogram' : null;
      if (!kind) continue;
      const block = m[kind === 'exphistogram' ? 'exponentialHistogram' : kind];
      for (const dp of (block.dataPoints || []).slice(0, 200)) {
        const rec = { service, name: cap(String(m.name), 200), unit: cap(String(m.unit || ''), 30), description: cap(String(m.description || ''), 200),
          kind: kind === 'exphistogram' ? 'histogram' : kind, attrs: attrs(dp.attributes), time: nanoToMs(dp.timeUnixNano) || Date.now(),
          monotonic: kind === 'sum' ? block.isMonotonic !== false : false,
          temporality: Number(block.aggregationTemporality) === 1 ? 'delta' : 'cumulative' };
        if (rec.kind === 'histogram') {
          rec.count = Number(dp.count) || 0; rec.sum = Number(dp.sum) || 0;
          rec.value = rec.count ? rec.sum / rec.count : 0;
          if (kind === 'histogram') { rec.bounds = numArr(dp.explicitBounds); rec.buckets = numArr(dp.bucketCounts); }
        } else {
          rec.value = Number(dp.asDouble ?? dp.asInt ?? 0);
        }
        out.push(rec);
      }
    }
  }
  return out;
}

module.exports = { parseTraces, parseLogs, parseMetrics };
