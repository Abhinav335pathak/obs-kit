#!/usr/bin/env node
'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

const auth = require('./auth');
const { Store } = require('./store');
const otlp = require('./otlp');
const proto = require('./proto');
const PKG = (() => { try { return require('../../package.json'); } catch { return { version: '0.0.0' }; } })();

const MAX_BODY = 4 * 1024 * 1024;
const COOKIE = 'obs_session';

function createViewer(env = process.env) {
  const cfg = {
    host: env.OBS_VIEWER_HOST || '127.0.0.1',
    uiPort: Number(env.OBS_UI_PORT || 7800),
    ingestHost: env.OBS_INGEST_HOST || env.OBS_VIEWER_HOST || '127.0.0.1',
    ingestPort: Number(env.OBS_INGEST_PORT || 4320),
    tlsCert: env.OBS_TLS_CERT, tlsKey: env.OBS_TLS_KEY, tlsCa: env.OBS_TLS_CA, // CA set => ingest requires a client cert
    retentionMs: Number(env.OBS_RETENTION_MIN || 60) * 60000,
    sessionTtlMs: Number(env.OBS_SESSION_MIN || 60) * 60000,
  };
  const tls = !!(cfg.tlsCert && cfg.tlsKey);
  const generated = {};

  // Credentials: use supplied ones; otherwise generate and show them once.
  let tokens = (env.OBS_INGEST_TOKENS || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (!tokens.length && !cfg.tlsCa) { generated.ingestToken = crypto.randomBytes(24).toString('base64url'); tokens = [generated.ingestToken]; }
  let passwordHash = env.OBS_OWNER_PASSWORD_HASH;
  if (!passwordHash) { generated.ownerPassword = crypto.randomBytes(12).toString('base64url'); passwordHash = auth.hashPassword(generated.ownerPassword); }
  const sessionSecret = env.OBS_SESSION_SECRET || crypto.randomBytes(32).toString('hex');

  const verifyIngest = auth.makeIngestVerifier(tokens);
  const sessions = auth.makeSessions(sessionSecret, cfg.sessionTtlMs);
  const links = auth.makeLinks(sessionSecret);
  const limiter = auth.makeLimiter(5, 15 * 60000);
  const store = new Store({ retentionMs: cfg.retentionMs });
  const sse = new Set();

  const sec = {
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
    'Cache-Control': 'no-store', 'Cross-Origin-Resource-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
  };
  const send = (res, code, body, type = 'application/json') => {
    res.writeHead(code, { ...sec, 'Content-Type': type });
    res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
  };

  function readBody(req, res) {
    return new Promise((resolve) => {
      const chunks = []; let size = 0; let done = false;
      const fail = (code, msg) => { if (!done) { done = true; send(res, code, { error: msg }); req.destroy(); resolve(null); } };
      req.on('data', (c) => { size += c.length; if (size > MAX_BODY) return fail(413, 'payload too large'); chunks.push(c); });
      req.on('error', () => fail(400, 'bad request'));
      req.on('end', () => {
        if (done) return;
        let buf = Buffer.concat(chunks);
        const enc = (req.headers['content-encoding'] || '').toLowerCase();
        try {
          if (enc === 'gzip') buf = zlib.gunzipSync(buf, { maxOutputLength: MAX_BODY * 4 });
          else if (enc && enc !== 'identity') return fail(415, 'unsupported content-encoding');
        } catch { return fail(400, 'bad gzip body'); }
        done = true; resolve(buf);
      });
    });
  }

  // ---- ingest listener (services / collector push here) ----------------------
  async function ingestHandler(req, res) {
    const url = req.url.split('?')[0];
    if (req.method === 'GET' && url === '/healthz') return send(res, 200, { ok: true });
    // With a CA configured, a client cert signed by it is REQUIRED; if tokens are
    // also configured, a valid token is required too (both layers must pass).
    const certOk = !cfg.tlsCa || req.socket.authorized === true;
    const tokenOk = !tokens.length || verifyIngest(req.headers.authorization);
    if (!certOk || !tokenOk) {
      res.setHeader('WWW-Authenticate', 'Bearer');
      return send(res, 401, { error: 'unauthorized' });
    }
    const handlers = {
      '/v1/traces': [otlp.parseTraces, 'addSpans', proto.decodeTraces],
      '/v1/logs': [otlp.parseLogs, 'addLogs', proto.decodeLogs],
      '/v1/metrics': [otlp.parseMetrics, 'addMetrics', proto.decodeMetrics],
    };
    const h = handlers[url];
    if (req.method !== 'POST' || !h) return send(res, 404, { error: 'not found' });
    const ctype = (req.headers['content-type'] || '').toLowerCase();
    const isProto = ctype.startsWith('application/x-protobuf');
    if (!isProto && !ctype.startsWith('application/json')) return send(res, 415, { error: 'send OTLP over HTTP as application/json or application/x-protobuf (gRPC is not supported by the viewer; use the collector for gRPC)' });
    const buf = await readBody(req, res); if (!buf) return;
    let body;
    try { body = isProto ? h[2](buf) : JSON.parse(buf.toString('utf8')); } catch { return send(res, 400, { error: isProto ? 'invalid protobuf' : 'invalid json' }); }
    store[h[1]](h[0](body));
    for (const c of sse) c.write(`event: tick\ndata: ${store.version}\n\n`);
    if (isProto) { res.writeHead(200, { ...sec, 'Content-Type': 'application/x-protobuf' }); return res.end(); } // empty Export*ServiceResponse
    send(res, 200, {});
  }

  // ---- UI listener (owner browser) -----------------------------------------
  const PUB = path.join(__dirname, 'public');
  const STATIC = {
    '/': ['index.html', 'text/html; charset=utf-8'], '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
    '/charts.js': ['charts.js', 'text/javascript; charset=utf-8'], '/app.css': ['app.css', 'text/css; charset=utf-8'],
  };
  const assets = {}; // read once; static files never change while running
  const asset = (f) => (assets[f] = assets[f] || fs.readFileSync(path.join(PUB, f)));
  const isAuthed = (req) => !!sessions.verify(auth.parseCookies(req.headers.cookie)[COOKIE]);
  const cookieAttrs = `Path=/; HttpOnly; SameSite=Strict${tls || env.OBS_COOKIE_SECURE === '1' ? '; Secure' : ''}`;
  const sessionCookie = () => `${COOKIE}=${sessions.issue()}; ${cookieAttrs}; Max-Age=${Math.floor(cfg.sessionTtlMs / 1000)}`;
  const sameOrigin = (req) => { const o = req.headers.origin; if (!o) return true; try { return new URL(o).host === req.headers.host; } catch { return false; } };

  async function uiHandler(req, res) {
    const u = new URL(req.url, 'http://x'); const p = u.pathname;
    if (req.method === 'GET' && STATIC[p]) return send(res, 200, asset(STATIC[p][0]), STATIC[p][1]);
    if (req.method === 'GET' && p === '/favicon.ico') { res.writeHead(204, sec); return res.end(); }
    if (req.method === 'GET' && p === '/auth/link') { // single-use sign-in link printed by `obs-kit dashboard`
      if (!links.consume(u.searchParams.get('t'))) return send(res, 401, 'This sign-in link is invalid, expired or already used. Run `npx obs-kit dashboard` for a new one.', 'text/plain; charset=utf-8');
      res.writeHead(302, { ...sec, Location: '/', 'Set-Cookie': sessionCookie() }); return res.end();
    }
    if (p === '/api/login' && req.method === 'POST') {
      if (!sameOrigin(req)) return send(res, 403, { error: 'bad origin' });
      if (!/^application\/json/i.test(req.headers['content-type'] || '')) return send(res, 415, { error: 'json required' });
      const key = req.socket.remoteAddress;
      if (limiter.blocked(key)) return send(res, 429, { error: 'too many attempts, try later' });
      const buf = await readBody(req, res); if (!buf) return;
      let pw = ''; try { pw = String(JSON.parse(buf.toString()).password ?? ''); } catch { /* fallthrough */ }
      if (!auth.verifyPassword(pw, passwordHash)) { limiter.fail(key); return send(res, 401, { error: 'invalid credentials' }); }
      limiter.clear(key);
      res.setHeader('Set-Cookie', sessionCookie());
      return send(res, 200, { ok: true });
    }
    if (p === '/api/logout' && req.method === 'POST') {
      res.setHeader('Set-Cookie', `${COOKIE}=; ${cookieAttrs}; Max-Age=0`);
      return send(res, 200, { ok: true });
    }
    if (p === '/api/session') return send(res, 200, { authed: isAuthed(req) }); // lets the page decide login vs app without a console-noisy 401
    if (!p.startsWith('/api/')) return send(res, 404, { error: 'not found' });
    if (!isAuthed(req)) return send(res, 401, { error: 'login required' });

    const q = u.searchParams;
    const windowMs = (() => { const m = /^(\d+)(s|m|h)$/.exec(q.get('window') || '15m'); const ms = m ? Number(m[1]) * { s: 1e3, m: 6e4, h: 36e5 }[m[2]] : 9e5; return Math.min(Math.max(ms, 60000), cfg.retentionMs); })();
    if (p === '/api/stream') {
      res.writeHead(200, { ...sec, 'Content-Type': 'text/event-stream', Connection: 'keep-alive' });
      res.write(`event: tick\ndata: ${store.version}\n\n`);
      sse.add(res); req.on('close', () => sse.delete(res)); return;
    }
    if (p === '/api/info') return send(res, 200, { ...store.info(), appVersion: PKG.version, retentionMs: cfg.retentionMs, sources: [...store.sources.values()].map((s) => ({ service: s.service, type: s.type, lastSeen: s.lastSeen, signals: s.signals })) });
    if (p === '/api/overview') return send(res, 200, store.overview(windowMs));
    if (p === '/api/graph') return send(res, 200, store.graph(windowMs));
    if (p === '/api/services') return send(res, 200, store.overview(windowMs).services);
    let m = /^\/api\/service\/([^/]+)$/.exec(p);
    if (m) { let name; try { name = decodeURIComponent(m[1]); } catch { return send(res, 400, { error: 'bad name' }); } const d = store.serviceDetail(name, windowMs); return d ? send(res, 200, d) : send(res, 404, { error: 'unknown service' }); }
    if (p === '/api/traces') {
      return send(res, 200, store.traces({ service: q.get('service') || undefined, minMs: Number(q.get('minMs') || 0), errorsOnly: q.get('errors') === '1', q: q.get('q') || undefined, windowMs }));
    }
    m = /^\/api\/traces\/([0-9a-f]{1,64})$/i.exec(p);
    if (m) return send(res, 200, { spans: store.trace(m[1]), logs: store.logsFor({ traceId: m[1] }) });
    if (p === '/api/logs') return send(res, 200, store.logsFor({ service: q.get('service') || undefined, severity: q.get('severity') || undefined, q: q.get('q') || undefined, windowMs }));
    if (p === '/api/metrics') return send(res, 200, store.metricsList({ service: q.get('service') || undefined, q: q.get('q') || undefined }));
    if (p === '/api/forget' && req.method === 'POST') {
      if (!sameOrigin(req)) return send(res, 403, { error: 'bad origin' });
      const svc = q.get('service'); if (!svc) return send(res, 400, { error: 'service required' }); store.forget(svc); return send(res, 200, { ok: true });
    }
    return send(res, 404, { error: 'not found' });
  }

  const wrap = (fn) => (req, res) => fn(req, res).catch((e) => { console.error('handler error:', e.message); if (!res.headersSent) send(res, 500, { error: 'internal error' }); });
  const tlsOpts = tls ? { cert: fs.readFileSync(cfg.tlsCert), key: fs.readFileSync(cfg.tlsKey) } : null;
  const ingestTls = tls && cfg.tlsCa ? { ...tlsOpts, ca: fs.readFileSync(cfg.tlsCa), requestCert: true, rejectUnauthorized: false } : tlsOpts; // authorized flag checked per request
  const mk = (opts, h) => (opts ? https.createServer(opts, wrap(h)) : http.createServer(wrap(h)));
  const ingest = mk(ingestTls, ingestHandler);
  const ui = mk(tlsOpts, uiHandler);
  const timer = setInterval(() => store.prune(), 60000); timer.unref();
  const keepalive = setInterval(() => { for (const c of sse) c.write(': ping\n\n'); }, 25000); keepalive.unref();

  return {
    cfg, store, generated, tls,
    start() {
      return Promise.all([
        new Promise((r) => ingest.listen(cfg.ingestPort, cfg.ingestHost, r)),
        new Promise((r) => ui.listen(cfg.uiPort, cfg.host, r)),
      ]).then(() => ({ uiPort: ui.address().port, ingestPort: ingest.address().port }));
    },
    stop() { for (const c of sse) c.end(); return Promise.all([new Promise((r) => ingest.close(r)), new Promise((r) => ui.close(r))]); },
  };
}

module.exports = { createViewer };

if (require.main === module) {
  const v = createViewer();
  v.start().then((ports) => {
    const scheme = v.tls ? 'https' : 'http';
    console.log(`obskit viewer\n  UI      ${scheme}://${v.cfg.host}:${ports.uiPort}\n  ingest  ${scheme}://${v.cfg.ingestHost}:${ports.ingestPort}  (POST /v1/{traces,metrics,logs}, OTLP/JSON)`);
    if (v.generated.ownerPassword) console.log(`\n  Owner password (shown once, set OBS_OWNER_PASSWORD_HASH to make it permanent):\n    ${v.generated.ownerPassword}`);
    if (v.generated.ingestToken) console.log(`\n  Ingest token (shown once, set OBS_INGEST_TOKENS to make it permanent):\n    ${v.generated.ingestToken}`);
    if (!v.tls && v.cfg.host !== '127.0.0.1') console.warn('\n  WARNING: listening beyond localhost without TLS. Set OBS_TLS_CERT/OBS_TLS_KEY.');
  });
}
