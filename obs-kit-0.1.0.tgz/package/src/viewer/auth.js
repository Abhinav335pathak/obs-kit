'use strict';
const crypto = require('crypto');

// ---- ingest tokens (service/collector -> viewer) ---------------------------
// Compare SHA-256 digests in constant time so length/prefix don't leak.
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
function makeIngestVerifier(tokens) {
  const digests = tokens.filter(Boolean).map(sha);
  return (headerValue) => {
    const m = /^Bearer\s+(.+)$/i.exec(headerValue || '');
    if (!m) return false;
    const d = sha(m[1].trim());
    let ok = false;
    for (const t of digests) ok = crypto.timingSafeEqual(t, d) || ok; // no early exit
    return ok;
  };
}

// ---- owner password (scrypt) ------------------------------------------------
function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const dk = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('hex')}$${dk.toString('hex')}`;
}
function verifyPassword(pw, stored) {
  const [alg, saltHex, hashHex] = String(stored).split('$');
  if (alg !== 'scrypt' || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const dk = crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), expected.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(dk, expected);
}

// ---- stateless signed sessions (HMAC, no server-side store) -------------------
const b64u = (b) => Buffer.from(b).toString('base64url');
function makeSessions(secret, ttlMs) {
  const sign = (p) => crypto.createHmac('sha256', secret).update(p).digest('base64url');
  return {
    issue(role = 'owner') {
      const payload = b64u(JSON.stringify({ role, exp: Date.now() + ttlMs, n: crypto.randomBytes(8).toString('hex') }));
      return `${payload}.${sign(payload)}`;
    },
    verify(token) {
      if (!token || typeof token !== 'string') return null;
      const [payload, sig] = token.split('.');
      if (!payload || !sig) return null;
      const good = Buffer.from(sign(payload));
      const got = Buffer.from(sig);
      if (good.length !== got.length || !crypto.timingSafeEqual(good, got)) return null;
      try {
        const s = JSON.parse(Buffer.from(payload, 'base64url').toString());
        return s.exp > Date.now() && s.role === 'owner' ? s : null;
      } catch { return null; }
    },
  };
}

// ---- single-use login links (minted by the local CLI, consumed once by the viewer) ----
function makeLinks(secret, ttlMs = 5 * 60000) {
  const sign = (p) => crypto.createHmac('sha256', secret).update('link:' + p).digest('base64url');
  const used = new Map();
  return {
    issue() {
      const payload = b64u(JSON.stringify({ exp: Date.now() + ttlMs, n: crypto.randomBytes(12).toString('hex') }));
      return `${payload}.${sign(payload)}`;
    },
    consume(token) {
      if (!token || typeof token !== 'string') return false;
      const [payload, sig] = token.split('.'); if (!payload || !sig) return false;
      const good = Buffer.from(sign(payload)); const got = Buffer.from(sig);
      if (good.length !== got.length || !crypto.timingSafeEqual(good, got)) return false;
      let p; try { p = JSON.parse(Buffer.from(payload, 'base64url').toString()); } catch { return false; }
      const now = Date.now(); for (const [k, exp] of used) if (exp < now) used.delete(k);
      if (!(p.exp > now) || used.has(p.n)) return false;
      used.set(p.n, p.exp); return true;
    },
  };
}

// ---- login throttling ---------------------------------------------------------
function makeLimiter(max, windowMs) {
  const hits = new Map();
  return {
    blocked(key) {
      const now = Date.now();
      const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
      hits.set(key, arr);
      return arr.length >= max;
    },
    fail(key) { const a = hits.get(key) || []; a.push(Date.now()); hits.set(key, a); },
    clear(key) { hits.delete(key); },
  };
}

function parseCookies(h) {
  const out = {};
  for (const part of String(h || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  }
  return out;
}

module.exports = { makeIngestVerifier, hashPassword, verifyPassword, makeSessions, makeLinks, makeLimiter, parseCookies };

if (require.main === module && process.argv[2] === 'hash') {
  const pw = process.argv[3];
  if (!pw) { console.error('usage: node auth.js hash <password>'); process.exit(1); }
  console.log(hashPassword(pw));
}
