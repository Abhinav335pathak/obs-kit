'use strict';
// Bounded in-memory telemetry store + on-demand aggregation. Nothing touches disk.
const crypto = require('crypto');

const LEVEL = { TRACE: 1, DEBUG: 2, INFO: 3, WARN: 4, WARNING: 4, ERROR: 5, FATAL: 6 };
const isEntry = (s) => s.kind === 2 || s.kind === 5 || !s.parentSpanId; // SERVER / CONSUMER / root
const pct = (sorted, p) => (sorted.length ? sorted[Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length))] : 0);
const r2 = (n) => Math.round(n * 100) / 100;

function stepFor(windowMs) { return Math.max(5000, Math.round(windowMs / 60 / 1000) * 1000); }

function hostOf(a) {
  const h = a['server.address'] || a['net.peer.name'] || a['http.host'] || a['peer.service'];
  if (h) return String(h);
  const u = a['url.full'] || a['http.url'];
  if (u) { try { return new URL(String(u)).host; } catch { /* ignore */ } }
  return null;
}
function quantileFromBuckets(bounds, counts, q) {
  const total = counts.reduce((a, b) => a + b, 0); if (!total || !bounds.length) return 0;
  let acc = 0; const target = q * total;
  for (let i = 0; i < counts.length; i++) {
    acc += counts[i];
    if (acc >= target) {
      if (i >= bounds.length) return bounds[bounds.length - 1];
      const lo = i === 0 ? Math.min(0, bounds[0]) : bounds[i - 1]; const hi = bounds[i];
      const inBucket = counts[i] || 1; const into = target - (acc - counts[i]);
      return lo + (hi - lo) * Math.min(1, Math.max(0, into / inBucket));
    }
  }
  return bounds[bounds.length - 1];
}

class Store {
  constructor({ maxSpans = 100000, maxLogs = 50000, retentionMs = 3600000, maxSeries = 5000, pointsPerSeries = 360 } = {}) {
    Object.assign(this, { maxSpans, maxLogs, retentionMs, maxSeries, pointsPerSeries });
    this.spans = []; this.logs = []; this.series = new Map(); this.sources = new Map();
    this.version = 0; this.startedAt = Date.now(); this.dropped = { series: 0 };
  }

  touch(service, signal, n, meta = {}) {
    let s = this.sources.get(service);
    if (!s) { s = { service, type: null, firstSeen: Date.now(), lastSeen: 0, host: null, pids: new Set(), signals: {} }; this.sources.set(service, s); }
    const g = (s.signals[signal] = s.signals[signal] || { batches: 0, items: 0, last: 0 });
    g.batches++; g.items += n; g.last = Date.now(); s.lastSeen = g.last;
    if (meta.type) s.type = meta.type; if (meta.host) s.host = meta.host; if (meta.pid != null && s.pids.size < 50) s.pids.add(meta.pid);
  }

  addSpans(a) {
    this.spans.push(...a); if (this.spans.length > this.maxSpans) this.spans.splice(0, this.spans.length - this.maxSpans);
    const by = new Map(); for (const s of a) { const e = by.get(s.service) || { n: 0, s }; e.n++; by.set(s.service, e); }
    for (const [svc, e] of by) this.touch(svc, 'traces', e.n, { type: e.s.serviceType, host: e.s.host, pid: e.s.pid });
    this.version++;
  }
  addLogs(a) {
    this.logs.push(...a); if (this.logs.length > this.maxLogs) this.logs.splice(0, this.logs.length - this.maxLogs);
    const by = new Map(); for (const l of a) by.set(l.service, (by.get(l.service) || 0) + 1);
    for (const [svc, n] of by) this.touch(svc, 'logs', n);
    this.version++;
  }
  addMetrics(a) {
    const seen = new Map();
    for (const m of a) {
      seen.set(m.service, (seen.get(m.service) || 0) + 1);
      const key = `${m.service}|${m.name}|${JSON.stringify(m.attrs)}`;
      let s = this.series.get(key);
      if (!s) {
        if (this.series.size >= this.maxSeries) { this.dropped.series++; continue; } // cardinality cap
        s = { id: crypto.createHash('sha1').update(key).digest('hex').slice(0, 10), service: m.service, name: m.name, unit: m.unit, description: m.description,
          kind: m.kind === 'sum' ? (m.monotonic ? 'counter' : 'gauge') : m.kind, attrs: m.attrs, points: [], p95: m.kind === 'histogram' ? [] : undefined, prev: null, last: 0 };
        if (s.kind === 'counter' && m.unit && !/\/s$/.test(m.unit)) s.unit = (m.unit === '1' ? '' : m.unit) + '/s';
        this.series.set(key, s);
      }
      this._point(s, m);
    }
    for (const [svc, n] of seen) this.touch(svc, 'metrics', n);
    this.version++;
  }
  _point(s, m) {
    const push = (arr, t, v) => { if (Number.isFinite(v)) { arr.push([t, v]); if (arr.length > this.pointsPerSeries) arr.shift(); } };
    s.last = m.time;
    if (s.kind === 'gauge') { push(s.points, m.time, m.value); return; }
    if (s.kind === 'counter') {
      const prev = s.prev; s.prev = { t: m.time, v: m.value }; s.total = m.temporality === 'cumulative' ? m.value : (s.total || 0) + m.value;
      if (m.temporality === 'delta') { const dt = prev ? (m.time - prev.t) / 1000 : 0; if (dt > 0) push(s.points, m.time, m.value / dt); return; }
      if (!prev) return;
      const dt = (m.time - prev.t) / 1000; if (dt <= 0) return;
      push(s.points, m.time, (m.value >= prev.v ? m.value - prev.v : m.value) / dt); return;
    }
    // histogram: derive interval mean + p95 from deltas of the cumulative data
    const prev = s.prev; s.prev = { count: m.count, sum: m.sum, buckets: m.buckets, t: m.time };
    let dCount = m.count, dSum = m.sum, dBuckets = m.buckets;
    if (m.temporality === 'cumulative' && prev && m.count >= prev.count) {
      dCount = m.count - prev.count; dSum = m.sum - prev.sum;
      dBuckets = m.buckets && prev.buckets && m.buckets.length === prev.buckets.length ? m.buckets.map((c, i) => Math.max(0, c - prev.buckets[i])) : m.buckets;
    }
    if (m.temporality === 'cumulative' && prev && dCount === 0) return; // no new observations this interval
    s.total = (m.temporality === 'cumulative' ? m.count : (s.total || 0) + m.count);
    push(s.points, m.time, dCount ? dSum / dCount : 0);
    if (m.bounds && dBuckets) push(s.p95, m.time, quantileFromBuckets(m.bounds, dBuckets, 0.95));
  }

  prune() {
    const cutoff = Date.now() - this.retentionMs;
    this.spans = this.spans.filter((s) => s.start >= cutoff);
    this.logs = this.logs.filter((l) => l.time >= cutoff);
    for (const [k, s] of this.series) {
      while (s.points.length && s.points[0][0] < cutoff) s.points.shift();
      if (s.p95) while (s.p95.length && s.p95[0][0] < cutoff) s.p95.shift();
      if (!s.points.length && s.last < cutoff) this.series.delete(k);
    }
  }
  forget(service) {
    this.spans = this.spans.filter((s) => s.service !== service); this.logs = this.logs.filter((l) => l.service !== service);
    for (const [k, s] of this.series) if (s.service === service) this.series.delete(k);
    this.sources.delete(service); this.version++;
  }

  info() {
    return { version: this.version, startedAt: this.startedAt, now: Date.now(), retentionMs: this.retentionMs,
      counts: { spans: this.spans.length, logs: this.logs.length, series: this.series.size, services: this.sources.size }, droppedSeries: this.dropped.series };
  }

  // ---- aggregation ---------------------------------------------------------------
  aggregate(windowMs) {
    const now = Date.now(); const step = stepFor(windowMs); const t0 = Math.floor((now - windowMs) / step) * step; const nb = Math.ceil((now - t0) / step) + 1;
    const per = new Map();
    const get = (svc) => { let e = per.get(svc); if (!e) { e = { buckets: Array.from({ length: nb }, () => ({ n: 0, err: 0, d: [] })), n: 0, err: 0, durs: [], sumMs: 0 }; per.set(svc, e); } return e; };
    for (const s of this.spans) {
      if (s.start < t0 || !isEntry(s)) continue;
      const e = get(s.service); const b = e.buckets[Math.min(nb - 1, Math.floor((s.start - t0) / step))];
      b.n++; e.n++; b.d.push(s.durationMs); e.durs.push(s.durationMs); e.sumMs += s.durationMs; if (s.error) { b.err++; e.err++; }
    }
    return { per, step, t0, nb, now };
  }
  _seriesOf(e, agg) {
    const t = [], rps = [], err = [], errRate = [], p50 = [], p95 = [], p99 = [], avg = [];
    e.buckets.forEach((b, i) => {
      // the newest bucket is still filling: divide by the time actually elapsed, or the chart dips to zero at the right edge
      const bs = agg.t0 + i * agg.step; const secs = Math.max(2000, Math.min(agg.step, agg.now - bs)) / 1000;
      t.push(bs); rps.push(r2(b.n / secs)); err.push(r2(b.err / secs)); errRate.push(b.n ? r2(b.err / b.n) : 0);
      const d = b.d.slice().sort((x, y) => x - y); p50.push(r2(pct(d, 50))); p95.push(r2(pct(d, 95))); p99.push(r2(pct(d, 99))); avg.push(b.n ? r2(d.reduce((x, y) => x + y, 0) / b.n) : 0);
    });
    return { t, rps, err, errRate, p50, p95, p99, avg };
  }
  _summary(e, windowMs) {
    const d = e.durs.slice().sort((x, y) => x - y);
    return { requests: e.n, errors: e.err, rps: r2(e.n / (windowMs / 1000)), errorRate: e.n ? r2(e.err / e.n) : 0, avgMs: e.n ? r2(e.sumMs / e.n) : 0, p50: r2(pct(d, 50)), p95: r2(pct(d, 95)), p99: r2(pct(d, 99)) };
  }
  _status(src, sum) {
    const alive = src && Date.now() - src.lastSeen < 90000;
    if (!alive) return 'offline'; if (!sum.requests) return 'idle';
    return sum.errorRate >= 0.2 ? 'critical' : sum.errorRate >= 0.05 ? 'degraded' : 'healthy';
  }
  _signals(src) {
    const o = {}; for (const k of ['traces', 'metrics', 'logs']) { const g = src && src.signals[k]; o[k] = g ? { last: g.last, items: g.items } : null; } return o;
  }
  _logCounts(windowMs, service) {
    const cutoff = Date.now() - windowMs; const c = { error: 0, warn: 0, total: 0 };
    for (const l of this.logs) { if (l.time < cutoff || (service && l.service !== service)) continue; c.total++; const lv = LEVEL[l.severity] || 3; if (lv >= 5) c.error++; else if (lv === 4) c.warn++; }
    return c;
  }

  overview(windowMs) {
    const agg = this.aggregate(windowMs); const names = new Set([...this.sources.keys(), ...agg.per.keys()]);
    const total = { buckets: Array.from({ length: agg.nb }, () => ({ n: 0, err: 0, d: [] })), n: 0, err: 0, durs: [], sumMs: 0 };
    const services = [];
    for (const name of names) {
      const e = agg.per.get(name) || { buckets: Array.from({ length: agg.nb }, () => ({ n: 0, err: 0, d: [] })), n: 0, err: 0, durs: [], sumMs: 0 };
      const src = this.sources.get(name); const sum = this._summary(e, windowMs);
      for (let i = 0; i < agg.nb; i++) { const b = e.buckets[i], t = total.buckets[i]; t.n += b.n; t.err += b.err; t.d.push(...b.d); }
      total.n += e.n; total.err += e.err; total.durs.push(...e.durs); total.sumMs += e.sumMs;
      const ser = this._seriesOf(e, agg);
      services.push({ name, type: src?.type || null, host: src?.host || null, instances: src ? src.pids.size : 0, status: this._status(src, sum), lastSeen: src?.lastSeen || 0,
        signals: this._signals(src), ...sum, logs: this._logCounts(windowMs, name), spark: { t: ser.t, rps: ser.rps, errRate: ser.errRate, p95: ser.p95 } });
    }
    services.sort((a, b) => b.requests - a.requests || a.name.localeCompare(b.name));
    return { window: windowMs, step: agg.step, summary: this._summary(total, windowMs), series: this._seriesOf(total, agg), services, logs: this._logCounts(windowMs) };
  }

  serviceDetail(name, windowMs) {
    const agg = this.aggregate(windowMs); const src = this.sources.get(name);
    const e = agg.per.get(name) || { buckets: Array.from({ length: agg.nb }, () => ({ n: 0, err: 0, d: [] })), n: 0, err: 0, durs: [], sumMs: 0 };
    if (!src && !agg.per.has(name)) return null;
    const cutoff = Date.now() - windowMs; const ops = new Map(); const errors = [];
    for (const s of this.spans) {
      if (s.service !== name || s.start < cutoff || !isEntry(s)) continue;
      let o = ops.get(s.name); if (!o) ops.set(s.name, (o = { name: s.name, n: 0, err: 0, d: [], last: 0 }));
      o.n++; o.d.push(s.durationMs); o.last = Math.max(o.last, s.start); if (s.error) { o.err++; errors.push(s); }
    }
    const endpoints = [...ops.values()].map((o) => { const d = o.d.sort((x, y) => x - y); return { name: o.name, requests: o.n, errors: o.err, errorRate: r2(o.err / o.n), avgMs: r2(d.reduce((a, b) => a + b, 0) / o.n), p95: r2(pct(d, 95)), maxMs: r2(d[d.length - 1] || 0), last: o.last }; })
      .sort((a, b) => b.requests - a.requests).slice(0, 50);
    errors.sort((a, b) => b.start - a.start);
    const logBuckets = this._logSeries(name, windowMs, agg);
    const metrics = [...this.series.values()].filter((s) => s.service === name).map((s) => this._seriesOut(s));
    const sum = this._summary(e, windowMs);
    const g = this.graph(windowMs);
    return { name, type: src?.type || null, host: src?.host || null, instances: src ? src.pids.size : 0, status: this._status(src, sum), firstSeen: src?.firstSeen || 0, lastSeen: src?.lastSeen || 0,
      signals: this._signals(src), summary: sum, series: this._seriesOf(e, agg), endpoints,
      errors: errors.slice(0, 20).map((s) => ({ traceId: s.traceId, name: s.name, message: s.statusMessage, time: s.start, durationMs: r2(s.durationMs) })),
      logs: logBuckets, logCounts: this._logCounts(windowMs, name), metrics,
      upstream: g.edges.filter((x) => x.to === name), downstream: g.edges.filter((x) => x.from === name), step: agg.step };
  }
  _logSeries(service, windowMs, agg) {
    const t = [], error = [], warn = [], info = []; for (let i = 0; i < agg.nb; i++) { t.push(agg.t0 + i * agg.step); error.push(0); warn.push(0); info.push(0); }
    for (const l of this.logs) {
      if (l.time < agg.t0 || (service && l.service !== service)) continue; const i = Math.min(agg.nb - 1, Math.floor((l.time - agg.t0) / agg.step)); const lv = LEVEL[l.severity] || 3;
      if (lv >= 5) error[i]++; else if (lv === 4) warn[i]++; else info[i]++;
    }
    return { t, error, warn, info };
  }
  _seriesOut(s) { return { id: s.id, service: s.service, name: s.name, unit: s.unit, description: s.description, kind: s.kind, attrs: s.attrs, points: s.points, p95: s.p95, total: s.total, last: s.last }; }

  graph(windowMs) {
    const cutoff = Date.now() - windowMs; const win = this.spans.filter((s) => s.start >= cutoff);
    const byId = new Map(win.map((s) => [s.spanId, s])); const remoteChild = new Set(); const edges = new Map(); const nodes = new Map();
    const node = (id, type) => { if (!nodes.has(id)) nodes.set(id, { id, type }); };
    const edge = (from, to, s) => { const k = `${from}>${to}`; const e = edges.get(k) || { from, to, calls: 0, errors: 0, sumMs: 0 }; e.calls++; e.sumMs += s.durationMs; if (s.error) e.errors++; edges.set(k, e); };
    for (const s of win) { const p = s.parentSpanId && byId.get(s.parentSpanId); if (p && p.service !== s.service) remoteChild.add(p.spanId); }
    for (const s of win) {
      node(s.service, 'service');
      const p = s.parentSpanId && byId.get(s.parentSpanId);
      if (p && p.service !== s.service) { node(p.service, 'service'); edge(p.service, s.service, s); continue; }
      if (s.kind === 3 && !remoteChild.has(s.spanId)) { // outbound call to something we have no spans for
        const a = s.attributes; let id = null, type = null;
        if (a['db.system']) { id = String(a['db.system']); type = 'database'; } else if (a['messaging.system']) { id = String(a['messaging.system']); type = 'queue'; }
        else { const h = hostOf(a); if (h) { id = h; type = 'external'; } }
        if (id && !this.sources.has(id)) { node(id, type); edge(s.service, id, s); }
      }
    }
    for (const n of this.sources.keys()) node(n, 'service');
    return { nodes: [...nodes.values()], edges: [...edges.values()].map((e) => ({ ...e, avgMs: r2(e.sumMs / e.calls), sumMs: undefined })) };
  }

  traces({ service, minMs = 0, errorsOnly = false, q, windowMs, limit = 100 } = {}) {
    const cutoff = windowMs ? Date.now() - windowMs : 0; const groups = new Map();
    for (const s of this.spans) { if (s.start < cutoff) continue; let g = groups.get(s.traceId); if (!g) groups.set(s.traceId, (g = [])); g.push(s); }
    const needle = q ? String(q).toLowerCase() : null; const out = [];
    for (const [traceId, spans] of groups) {
      const root = spans.find((s) => !s.parentSpanId) || spans.reduce((a, b) => (a.start <= b.start ? a : b));
      const start = Math.min(...spans.map((s) => s.start)); const end = Math.max(...spans.map((s) => s.start + s.durationMs));
      const t = { traceId, name: root.name, rootService: root.service, start, durationMs: r2(end - start), spanCount: spans.length, errors: spans.filter((s) => s.error).length, services: [...new Set(spans.map((s) => s.service))] };
      if (service && !t.services.includes(service)) continue; if (t.durationMs < minMs) continue; if (errorsOnly && !t.errors) continue;
      if (needle && !(t.name.toLowerCase().includes(needle) || traceId.startsWith(needle) || spans.some((s) => s.name.toLowerCase().includes(needle)))) continue;
      out.push(t);
    }
    return out.sort((a, b) => b.start - a.start).slice(0, limit);
  }
  trace(id) { return this.spans.filter((s) => s.traceId === id).sort((a, b) => a.start - b.start); }

  logsFor({ traceId, service, severity, q, windowMs, limit = 500 } = {}) {
    const cutoff = windowMs ? Date.now() - windowMs : 0; const min = severity ? LEVEL[String(severity).toUpperCase()] || 0 : 0; const needle = q ? String(q).toLowerCase() : null; const out = [];
    for (let i = this.logs.length - 1; i >= 0 && out.length < limit; i--) {
      const l = this.logs[i];
      if (l.time < cutoff || (traceId && l.traceId !== traceId) || (service && l.service !== service)) continue;
      if (min && (LEVEL[l.severity] || 3) < min) continue; if (needle && !l.body.toLowerCase().includes(needle)) continue; out.push(l);
    }
    return out.sort((a, b) => b.time - a.time);
  }
  metricsList({ service, q } = {}) {
    const needle = q ? String(q).toLowerCase() : null;
    return [...this.series.values()].filter((s) => (!service || s.service === service) && (!needle || s.name.toLowerCase().includes(needle))).map((s) => this._seriesOut(s));
  }
}

module.exports = { Store, quantileFromBuckets };
