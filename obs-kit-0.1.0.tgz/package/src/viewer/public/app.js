'use strict';
// obs-kit dashboard. All telemetry is untrusted: it is only written via textContent / numeric attributes.
(function () {
  const { h, s, paint, fmt, timeChart, legend, sparkline } = window.Charts;
  const $ = (id) => document.getElementById(id);
  const C = { blue: 'var(--blue)', teal: 'var(--teal)', amber: 'var(--amber)', violet: 'var(--violet)', red: 'var(--red)', slate: 'var(--slate)' };
  const RANGES = ['5m', '15m', '1h'];
  const store = { get(k, d) { try { return localStorage.getItem(k) || d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, v); } catch { /* private mode */ } } };
  const ui = { range: RANGES.includes(store.get('obs.range', '15m')) ? store.get('obs.range', '15m') : '15m', paused: false, page: null, key: '', seq: 0, es: null, timer: null, poll: null, info: null };

  // ---------- api / auth ----------
  async function api(path, opts) {
    const r = await fetch(path, { credentials: 'same-origin', ...opts });
    if (r.status === 401) { showLogin(); throw new Error('auth'); }
    const body = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(body.error || r.statusText); e.status = r.status; throw e; }
    return body;
  }
  const q = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== '' && v != null && v !== false)).toString();
  function showLogin() { $('app').hidden = true; $('login').hidden = false; if (ui.es) { ui.es.close(); ui.es = null; } clearInterval(ui.poll); }
  function showApp() { $('login').hidden = true; $('app').hidden = false; connect(); route(); clearInterval(ui.poll); ui.poll = setInterval(() => { if (!ui.paused) refresh(); }, 5000); }
  $('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault(); $('loginErr').textContent = '';
    const r = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: $('pw').value }) });
    $('pw').value = ''; if (r.ok) showApp(); else $('loginErr').textContent = (await r.json().catch(() => ({}))).error || 'sign-in failed';
  });
  $('logout').addEventListener('click', async () => { await fetch('/api/logout', { method: 'POST' }); showLogin(); });

  // ---------- chrome: nav, range, live ----------
  const ICON = {
    overview: 'M3 12l9-8 9 8M5 10v10h5v-6h4v6h5V10', map: 'M6 6a2 2 0 100-.01M18 6a2 2 0 100-.01M12 18a2 2 0 100-.01M7.5 7.5L11 16M16.5 7.5L13 16',
    traces: 'M3 6h12M6 12h12M9 18h12', logs: 'M4 5h16M4 10h16M4 15h10M4 20h7', metrics: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  };
  const NAV = [['overview', 'Overview'], ['map', 'Service map'], ['traces', 'Traces'], ['logs', 'Logs'], ['metrics', 'Metrics']];
  function buildNav() {
    const nav = $('nav'); nav.replaceChildren();
    for (const [id, label] of NAV) {
      const svg = s('svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true' }); s('path', { d: ICON[id] }, svg);
      const a = h('a', { href: '#/' + id, 'data-id': id }); a.append(svg, document.createTextNode(label)); nav.append(a);
    }
    const rg = $('range'); rg.replaceChildren();
    for (const r of RANGES) { const b = h('button', { type: 'button', text: r, class: r === ui.range ? 'on' : '' }); b.addEventListener('click', () => { ui.range = r; store.set('obs.range', r); for (const x of rg.children) x.classList.toggle('on', x.textContent === r); refresh(); }); rg.append(b); }
  }
  $('pause').addEventListener('click', () => { ui.paused = !ui.paused; $('pause').textContent = ui.paused ? 'Paused' : 'Live'; $('pause').classList.toggle('paused', ui.paused); if (!ui.paused) refresh(); });
  function connect() {
    if (ui.es) ui.es.close();
    ui.es = new EventSource('/api/stream');
    ui.es.onopen = () => setConn(true);
    ui.es.addEventListener('tick', () => { setConn(true); if (!ui.paused) { clearTimeout(ui.timer); ui.timer = setTimeout(refresh, 800); } });
    ui.es.onerror = () => setConn(false);
  }
  function setConn(on) { const c = $('conn'); c.classList.toggle('on', on); c.querySelector('span').textContent = on ? 'live' : 'reconnecting…'; }

  // ---------- small components ----------
  const text = (t, cls) => h('span', { class: cls || '', text: t });
  const pill = (st) => h('span', { class: 'pill ' + st }, h('i'), document.createTextNode(st));
  function signals(sig) {
    const w = h('span', { class: 'sig' });
    for (const [k, l, name] of [['traces', 'T', 'Traces'], ['metrics', 'M', 'Metrics'], ['logs', 'L', 'Logs']]) {
      const g = sig && sig[k]; w.append(h('b', { class: g ? 'on' : '', text: l, title: g ? `${name}: ${g.items} received, last ${fmt.ago(g.last)}` : `${name}: none received yet` }));
    }
    return w;
  }
  function card(title, body, right) { const c = h('section', { class: 'card' }); if (title) c.append(h('h3', {}, text(title), right || '')); c.append(body); return c; }
  function note(...parts) { const n = h('div', { class: 'note' }); for (const p of parts) n.append(typeof p === 'string' ? document.createTextNode(p) : p); return n; }
  const b = (t) => h('b', { text: t });
  const code = (t) => h('code', { text: t });
  function kpi({ label, value, sub, series, color, cls }) {
    const k = h('div', { class: 'card kpi ' + (cls || '') }, h('div', { class: 'lbl', text: label }), h('div', { class: 'val', text: value }));
    const row = h('div', { class: 'sub' }, text(sub || '')); if (series) row.append(sparkline(series, color || C.blue)); k.append(row); return k;
  }
  const tbl = (cols, rows, opts = {}) => {
    const t = h('table', { class: 'tbl' }); const thead = h('thead'); const tr = h('tr');
    cols.forEach((c) => tr.append(h('th', { class: c.r ? 'r' : '', text: c.label }))); thead.append(tr); t.append(thead);
    const tb = h('tbody'); for (const r of rows) { const row = h('tr', { class: r.onclick ? 'click' : '' }); if (r.onclick) { row.tabIndex = 0; row.addEventListener('click', r.onclick); row.addEventListener('keydown', (e) => { if (e.key === 'Enter') r.onclick(); }); }
      cols.forEach((c, i) => { const td = h('td', { class: (c.r ? 'r ' : '') + (c.cls || '') }); const v = r.cells[i]; if (v instanceof Node) td.append(v); else td.textContent = v == null ? '' : String(v); row.append(td); }); tb.append(row); }
    t.append(tb); return h('div', { class: 'tablewrap' }, t);
  };
  const go = (hash) => () => { location.hash = hash; };
  const svcLink = (name) => { const a = h('a', { href: '#/service/' + encodeURIComponent(name), text: name }); return a; };
  const statusClass = (r) => (r >= 0.2 ? 'bad' : r >= 0.05 ? 'warn' : '');

  function onboarding(info) {
    const c = h('div', { class: 'card' }); c.append(h('h3', {}, text('Waiting for telemetry')));
    c.append(h('p', { class: 'muted' }, document.createTextNode('No service has reported yet. Start your app with the CLI and data will appear here within seconds:')));
    c.append(h('pre', { class: 'mono' , text: 'npx obs-kit init      # once per project\nnpx obs-kit start     # runs your app with telemetry on' }));
    c.append(h('p', { class: 'muted small' }, document.createTextNode('Nothing arriving? Run '), code('npx obs-kit doctor'), document.createTextNode(' to check configuration and connectivity.')));
    if (info) c.append(h('p', { class: 'muted small', text: `Viewer up since ${fmt.time(info.startedAt, true)}.` }));
    return c;
  }

  // ---------- pages ----------
  // A page = { title, el, update() }. el is mounted once; update() refreshes inner containers only (keeps scroll and focus).
  function overviewPage() {
    const el = h('div'); const kp = h('div', { class: 'grid g5' }), charts = h('div', { class: 'grid g2 mt' }), tbWrap = h('div', { class: 'mt' }), failWrap = h('div', { class: 'mt' }); el.append(kp, charts, tbWrap, failWrap);
    return { title: 'Overview', el, async update() {
      const [ov, fails, info] = await Promise.all([api('/api/overview?' + q({ window: ui.range })), api('/api/traces?' + q({ window: ui.range, errors: 1 })), api('/api/info')]);
      ui.info = info; metaLine(info);
      if (!ov.services.length) { kp.replaceChildren(); charts.replaceChildren(); failWrap.replaceChildren(); tbWrap.replaceChildren(onboarding(info)); return; }
      const sm = ov.summary, se = ov.series; const live = ov.services.filter((x) => x.status !== 'offline').length; const bad = ov.services.filter((x) => x.status === 'critical' || x.status === 'degraded').length;
      kp.replaceChildren(
        kpi({ label: 'Requests / s', value: fmt.rate(sm.rps), sub: `${fmt.num(sm.requests)} in ${ui.range}`, series: se.rps, color: C.blue }),
        kpi({ label: 'Error rate', value: fmt.pct(sm.errorRate), sub: `${fmt.num(sm.errors)} failed`, series: se.errRate, color: C.red, cls: statusClass(sm.errorRate) }),
        kpi({ label: 'p95 latency', value: fmt.ms(sm.p95), sub: `p50 ${fmt.ms(sm.p50)}`, series: se.p95, color: C.amber }),
        kpi({ label: 'Services', value: `${live}/${ov.services.length}`, sub: bad ? `${bad} need attention` : 'all healthy', cls: bad ? 'warn' : '' }),
        kpi({ label: 'Errors logged', value: fmt.num(ov.logs.error), sub: `${fmt.num(ov.logs.warn)} warnings`, cls: ov.logs.error ? 'bad' : '' }));
      charts.replaceChildren(
        card('Traffic', h('div', {}, timeChart({ t: se.t, series: [{ name: 'Requests/s', values: se.rps, color: C.blue, type: 'area', format: fmt.rate }, { name: 'Errors/s', values: se.err, color: C.red, format: fmt.rate }], format: fmt.num }), legend([{ name: 'Requests/s', color: C.blue }, { name: 'Errors/s', color: C.red }]))),
        card('Latency', h('div', {}, timeChart({ t: se.t, series: [{ name: 'p50', values: se.p50, color: C.teal }, { name: 'p95', values: se.p95, color: C.amber }, { name: 'p99', values: se.p99, color: C.violet }], format: fmt.ms }), legend([{ name: 'p50', color: C.teal }, { name: 'p95', color: C.amber }, { name: 'p99', color: C.violet }]))));
      tbWrap.replaceChildren(card('Services', tbl(
        [{ label: 'Status' }, { label: 'Service' }, { label: 'Signals' }, { label: 'Req/s', r: 1 }, { label: 'Errors', r: 1 }, { label: 'p95', r: 1 }, { label: 'Trend' }, { label: 'Logged errors', r: 1 }, { label: 'Last seen', r: 1 }],
        ov.services.map((x) => ({ onclick: go('#/service/' + encodeURIComponent(x.name)), cells: [pill(x.status), h('span', {}, text(x.name, 'name'), x.type ? h('span', { class: 'tag', text: ' ' + x.type }) : ''), signals(x.signals), fmt.rate(x.rps), h('span', { class: statusClass(x.errorRate), text: x.requests ? fmt.pct(x.errorRate) : '–' }), x.requests ? fmt.ms(x.p95) : '–', sparkline(x.spark.rps, C.blue, 84, 22), h('span', { class: x.logs.error ? 'bad' : 'muted', text: String(x.logs.error) }), fmt.ago(x.lastSeen)] })))));
      failWrap.replaceChildren(card('Recent failing traces', fails.length ? h('div', { class: 'list' }, ...fails.slice(0, 6).map((t) => traceRow(t, 1))) : note('No failing traces in this window.')));
    } };
  }

  function traceRow(t, max, onClick, selected) {
    const r = h('div', { class: 'row' + (selected ? ' sel' : ''), tabindex: '0' });
    r.append(h('div', { class: 't' }, h('strong', { text: t.name }), h('span', { class: t.errors ? 'bad' : 'muted', text: t.errors ? `${t.errors} error${t.errors > 1 ? 's' : ''}` : fmt.ms(t.durationMs) })));
    r.append(h('small', { text: `${t.services.join(' → ')} · ${t.spanCount} spans · ${fmt.ms(t.durationMs)} · ${fmt.ago(t.start)}` }));
    const d = h('div', { class: 'dur' + (t.errors ? ' fail' : '') }); const i = h('i'); i.style.width = Math.max(2, Math.min(100, (t.durationMs / Math.max(max, 1)) * 100)) + '%'; d.append(i); r.append(d);
    const act = onClick || (() => { location.hash = '#/traces/' + t.traceId; }); r.addEventListener('click', act); r.addEventListener('keydown', (e) => { if (e.key === 'Enter') act(); }); return r;
  }

  function metricCard(m, height = 84) {
    const lastV = m.points.length ? m.points[m.points.length - 1][1] : null; const f = fmt.byUnit(m.unit);
    const attrs = Object.entries(m.attrs || {}).map(([k, v]) => `${k}=${v}`).join(' ');
    const ser = [{ name: m.kind === 'histogram' ? 'mean' : m.kind === 'counter' ? 'rate' : 'value', values: m.points.map((p) => p[1]), color: C.blue, type: 'area' }];
    if (m.p95 && m.p95.length === m.points.length) ser.push({ name: 'p95', values: m.p95.map((p) => p[1]), color: C.amber });
    const c = h('div', { class: 'card' });
    c.append(h('div', { class: 'card-h' }, h('span', { class: 'metricname', title: m.description || m.name, text: m.name }), h('span', { class: 'tag', text: m.kind })));
    c.append(h('div', { class: 'metricval', text: lastV == null ? '–' : f(lastV) + (m.kind === 'counter' && !/\/s$/.test(m.unit || '') ? '/s' : '') }));
    if (attrs) c.append(h('div', { class: 'muted small', text: attrs, title: attrs }));
    c.append(timeChart({ t: m.points.map((p) => p[0]), series: ser, height, format: f, empty: m.kind === 'counter' ? 'Needs two samples to compute a rate' : 'No data' })); return c;
  }

  function servicePage(name) {
    const el = h('div'); const head = h('div'), kp = h('div', { class: 'grid g5 mt' }), ch = h('div', { class: 'grid g2 mt' }), rt = h('div', { class: 'mt' }), ep = h('div', { class: 'mt' }), two = h('div', { class: 'grid g2 mt' }), lg = h('div', { class: 'mt' }), mt = h('div', { class: 'mt' });
    el.append(head, kp, ch, rt, ep, two, lg, mt);
    return { title: name, el, async update() {
      let d; try { d = await api(`/api/service/${encodeURIComponent(name)}?` + q({ window: ui.range })); } catch (e) { if (e.status === 404) { for (const x of [head, kp, ch, rt, ep, two, lg, mt]) x.replaceChildren(); head.replaceChildren(note(b(name), ' has no data in the viewer (never reported, or idle longer than the retention window). ', h('a', { href: '#/overview', text: 'Back to overview' }))); return; } throw e; }
      const sm = d.summary, se = d.series;
      head.replaceChildren(h('div', { class: 'card' }, h('div', { class: 'filters' }, pill(d.status), d.type ? h('span', { class: 'tag', text: d.type }) : '', signals(d.signals),
        h('span', { class: 'muted', text: [d.host && `host ${d.host}`, d.instances && `${d.instances} instance${d.instances > 1 ? 's' : ''}`, `first seen ${fmt.ago(d.firstSeen)}`, `last data ${fmt.ago(d.lastSeen)}`].filter(Boolean).join(' · ') }))));
      const missing = ['traces', 'metrics', 'logs'].filter((k) => !d.signals[k]);
      if (missing.length) head.append(h('div', { class: 'mt' }, note(b('Not received yet: '), missing.join(', '), '. ', hint(missing))));
      kp.replaceChildren(
        kpi({ label: 'Requests / s', value: fmt.rate(sm.rps), sub: `${fmt.num(sm.requests)} in ${ui.range}`, series: se.rps, color: C.blue }),
        kpi({ label: 'Error rate', value: sm.requests ? fmt.pct(sm.errorRate) : '–', sub: `${fmt.num(sm.errors)} failed`, series: se.errRate, color: C.red, cls: statusClass(sm.errorRate) }),
        kpi({ label: 'p95 latency', value: sm.requests ? fmt.ms(sm.p95) : '–', sub: `p50 ${fmt.ms(sm.p50)}`, series: se.p95, color: C.amber }),
        kpi({ label: 'p99 latency', value: sm.requests ? fmt.ms(sm.p99) : '–', sub: `avg ${fmt.ms(sm.avgMs)}`, series: se.p99, color: C.violet }),
        kpi({ label: 'Logged errors', value: fmt.num(d.logCounts.error), sub: `${fmt.num(d.logCounts.warn)} warnings`, cls: d.logCounts.error ? 'bad' : '' }));
      ch.replaceChildren(
        card('Traffic', h('div', {}, timeChart({ t: se.t, series: [{ name: 'Requests/s', values: se.rps, color: C.blue, type: 'area', format: fmt.rate }, { name: 'Errors/s', values: se.err, color: C.red, format: fmt.rate }], format: fmt.num, empty: d.signals.traces ? 'No requests in this window' : 'No traces received: request rate is derived from traces' }), legend([{ name: 'Requests/s', color: C.blue }, { name: 'Errors/s', color: C.red }]))),
        card('Latency', h('div', {}, timeChart({ t: se.t, series: [{ name: 'p50', values: se.p50, color: C.teal }, { name: 'p95', values: se.p95, color: C.amber }, { name: 'p99', values: se.p99, color: C.violet }], format: fmt.ms, empty: d.signals.traces ? 'No requests in this window' : 'No traces received' }), legend([{ name: 'p50', color: C.teal }, { name: 'p95', color: C.amber }, { name: 'p99', color: C.violet }]))));
      const pick = (n) => d.metrics.find((m) => m.name === n);
      const rtCards = [['process.cpu.utilization', 'CPU (cores)', fmt.num], ['process.memory.rss', 'Memory (RSS)', fmt.bytes], ['process.memory.heap_used', 'Heap used', fmt.bytes], ['nodejs.eventloop.delay.p99', 'Event-loop delay p99', fmt.ms]].map(([n, label, f]) => {
        const m = pick(n); if (!m) return null; return card(label, h('div', {}, h('div', { class: 'metricval', text: m.points.length ? f(m.points[m.points.length - 1][1]) : '–' }), timeChart({ t: m.points.map((p) => p[0]), series: [{ name: label, values: m.points.map((p) => p[1]), color: C.teal, type: 'area' }], height: 96, format: f })));
      }).filter(Boolean);
      rt.replaceChildren(rtCards.length ? h('div', { class: 'grid g4' }, ...rtCards) : '');
      ep.replaceChildren(card('Endpoints & operations', d.endpoints.length ? tbl([{ label: 'Operation' }, { label: 'Requests', r: 1 }, { label: 'Errors', r: 1 }, { label: 'Avg', r: 1 }, { label: 'p95', r: 1 }, { label: 'Max', r: 1 }],
        d.endpoints.map((x) => ({ onclick: go('#/traces?' + q({ service: name, q: x.name })), cells: [h('span', { class: 'name', text: x.name }), fmt.num(x.requests), h('span', { class: statusClass(x.errorRate), text: `${x.errors} (${fmt.pct(x.errorRate)})` }), fmt.ms(x.avgMs), fmt.ms(x.p95), fmt.ms(x.maxMs)] }))) : note('No requests recorded in this window.')));
      const deps = (list, dir) => (list.length ? tbl([{ label: dir === 'in' ? 'Caller' : 'Calls' }, { label: 'Calls', r: 1 }, { label: 'Errors', r: 1 }, { label: 'Avg', r: 1 }], list.map((e) => ({ cells: [dir === 'in' ? e.from : e.to, fmt.num(e.calls), e.errors, fmt.ms(e.avgMs)] }))) : note(dir === 'in' ? 'No callers observed.' : 'No outbound calls observed (databases, HTTP APIs and other services appear here).'));
      two.replaceChildren(card('Called by', deps(d.upstream, 'in')), card('Depends on', deps(d.downstream, 'out')));
      const lgs = d.logs; const infoV = lgs.info, warnT = lgs.warn.map((v, i) => v + infoV[i]), errT = lgs.error.map((v, i) => v + warnT[i]);
      lg.replaceChildren(h('div', { class: 'grid g2' }, card('Recent errors', d.errors.length ? h('div', { class: 'list' }, ...d.errors.slice(0, 6).map((e) => { const r = h('div', { class: 'row', tabindex: '0' }, h('div', { class: 't' }, h('strong', { text: e.name }), h('span', { class: 'muted', text: fmt.ago(e.time) })), h('small', { text: e.message || `${fmt.ms(e.durationMs)}, no status message` })); const a = go('#/traces/' + e.traceId); r.addEventListener('click', a); r.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') a(); }); return r; })) : note('No failed requests in this window.')),
        card('Log volume', h('div', {}, timeChart({ t: lgs.t, series: [{ name: 'error', values: errT, tip: lgs.error, color: C.red, type: 'bars' }, { name: 'warn', values: warnT, tip: lgs.warn, color: C.amber, type: 'bars' }, { name: 'info', values: infoV, tip: infoV, color: C.blue, type: 'bars' }], height: 150, format: fmt.num, empty: d.signals.logs ? 'No logs in this window' : 'No logs received yet' }), legend([{ name: 'error', color: C.red }, { name: 'warn', color: C.amber }, { name: 'info/debug', color: C.blue }]), h('p', { class: 'small' }, h('a', { href: '#/logs?' + q({ service: name }), text: 'Open logs →' }))))));
      const shown = d.metrics.filter((m) => !['process.cpu.utilization', 'process.memory.rss', 'process.memory.heap_used', 'nodejs.eventloop.delay.p99', 'obs_kit.sdk.up'].includes(m.name)).slice(0, 12);
      mt.replaceChildren(card(`Metrics (${d.metrics.length})`, d.metrics.length ? h('div', {}, shown.length ? h('div', { class: 'grid g3' }, ...shown.map((m) => metricCard(m))) : note('Only runtime metrics so far; application metrics (e.g. HTTP request duration) appear as your app handles traffic.'), h('p', { class: 'small' }, h('a', { href: '#/metrics?' + q({ service: name }), text: 'All metrics for this service →' }))) : note(b('No metrics received yet. '), 'The SDK exports metrics every 10 s, first within about 2 s of start. ', hint(['metrics']))));
    } };
  }
  const hint = (missing) => h('span', {}, document.createTextNode('Run '), code('npx obs-kit doctor'), document.createTextNode(missing.includes('metrics') || missing.includes('logs') ? ' to test the pipeline end to end.' : ' to check connectivity; traces only appear once the service handles a request.'));

  function tracesPage(params) {
    const f = { service: params.get('service') || '', q: params.get('q') || '', minMs: '', errors: false }; let sel = params.get('id') || null;
    const el = h('div'); const bar = h('div', { class: 'filters' }); const svc = h('select', { 'aria-label': 'Service' }); const search = h('input', { type: 'search', placeholder: 'Search operation or trace id', value: f.q }); const minI = h('input', { type: 'number', min: '0', placeholder: 'min ms' });
    const errL = h('label'); const errC = h('input', { type: 'checkbox' }); errL.append(errC, document.createTextNode('errors only')); bar.append(svc, search, minI, errL);
    const list = h('div', { class: 'list' }), detail = h('div'); const grid = h('div', { class: 'grid split' }, h('div', {}, list), detail); el.append(bar, grid);
    let timer; const rerun = () => { clearTimeout(timer); timer = setTimeout(() => page.update(), 250); };
    svc.addEventListener('change', () => { f.service = svc.value; rerun(); }); search.addEventListener('input', () => { f.q = search.value; rerun(); }); minI.addEventListener('input', () => { f.minMs = minI.value; rerun(); }); errC.addEventListener('change', () => { f.errors = errC.checked; rerun(); });
    const page = { title: 'Traces', el, async update() {
      const [ov, list_] = await Promise.all([api('/api/overview?' + q({ window: ui.range })), api('/api/traces?' + q({ window: ui.range, service: f.service, q: f.q, minMs: f.minMs, errors: f.errors ? 1 : '' }))]);
      const cur = svc.value || f.service; svc.replaceChildren(h('option', { value: '', text: 'All services' }), ...ov.services.map((x) => h('option', { value: x.name, text: x.name }))); svc.value = cur;
      const max = Math.max(1, ...list_.map((t) => t.durationMs)); list.replaceChildren();
      if (!list_.length) list.append(note('No traces match. Traces appear once a service handles a request.'));
      for (const t of list_) list.append(traceRow(t, max, () => { sel = t.traceId; history.replaceState(null, '', '#/traces/' + sel); page.update(); }, t.traceId === sel));
      if (sel) await showTrace(sel, detail); else detail.replaceChildren(note('Select a trace to see its span waterfall, attributes and correlated logs.'));
    } };
    return page;
  }

  async function showTrace(id, box) {
    let data; try { data = await api('/api/traces/' + encodeURIComponent(id)); } catch { box.replaceChildren(note('Could not load that trace.')); return; }
    const { spans, logs } = data; if (!spans.length) { box.replaceChildren(note('This trace has expired from the viewer’s memory window.')); return; }
    const t0 = Math.min(...spans.map((x) => x.start)), t1 = Math.max(...spans.map((x) => x.start + x.durationMs)), total = Math.max(t1 - t0, 0.001);
    const byId = new Map(spans.map((x) => [x.spanId, x])); const depth = new Map(); const dp = (x, g = 0) => { if (depth.has(x.spanId)) return depth.get(x.spanId); const p = byId.get(x.parentSpanId); const v = p && g < 40 ? dp(p, g + 1) + 1 : 0; depth.set(x.spanId, v); return v; };
    const attrBox = h('div', { class: 'mt' }); const wfBox = h('div');
    const rows = spans.map((sp) => { const r = h('div', { class: 'wf', tabindex: '0', title: sp.name }); const lbl = h('div', { class: 'lbl' }); lbl.style.paddingLeft = Math.min(dp(sp), 10) * 12 + 'px'; lbl.append(document.createTextNode(sp.name + ' '), h('em', { text: sp.service }));
      const lane = h('div', { class: 'lane' }); const bar = h('div', { class: 'bar' + (sp.error ? ' fail' : '') }); bar.style.left = (((sp.start - t0) / total) * 100).toFixed(3) + '%'; bar.style.width = Math.max((sp.durationMs / total) * 100, 0.4).toFixed(3) + '%'; lane.append(bar);
      r.append(lbl, lane, h('span', { class: 'd', text: fmt.ms(sp.durationMs) }));
      const pickSpan = () => { for (const x of wfBox.children) x.classList.remove('sel'); r.classList.add('sel'); const dl = h('dl', { class: 'kv' }); const add = (k, v) => dl.append(h('dt', { text: k }), h('dd', { text: String(v) }));
        add('span', sp.name); add('service', sp.service); add('duration', fmt.ms(sp.durationMs)); add('status', sp.error ? 'ERROR' + (sp.statusMessage ? ': ' + sp.statusMessage : '') : 'OK'); add('span id', sp.spanId); for (const [k, v] of Object.entries(sp.attributes)) add(k, v); attrBox.replaceChildren(card('Span details', dl)); };
      r.addEventListener('click', pickSpan); r.addEventListener('keydown', (e) => { if (e.key === 'Enter') pickSpan(); }); return r; });
    wfBox.append(...rows);
    const out = h('div', { class: 'card' }, h('h3', {}, text(`Trace ${id.slice(0, 12)}…`), text(`${fmt.ms(total)} · ${spans.length} spans`)), wfBox);
    box.replaceChildren(out, attrBox);
    if (logs.length) box.append(h('div', { class: 'mt' }, card('Logs in this trace', logList(logs))));
  }

  const sevOrder = ['', 'DEBUG', 'INFO', 'WARN', 'ERROR'];
  function logList(logs) {
    const w = h('div', { class: 'logs' }); if (!logs.length) return note('No logs match.');
    for (const l of logs.slice(0, 400)) { const r = h('div', { class: 'log mono' }); r.append(h('span', { class: 'muted', text: fmt.time(l.time, true) }), h('span', { class: 'sev ' + l.severity, text: l.severity }), h('span', { class: 'svc muted', text: l.service }), h('span', { class: 'body', text: l.body }));
      if (l.traceId) { const a = h('a', { href: '#/traces/' + l.traceId, text: ' ↗', title: 'Open trace' }); r.lastChild.append(a); } w.append(r); }
    return w;
  }
  function logsPage(params) {
    const f = { service: params.get('service') || '', severity: '', q: '' }; const el = h('div'); const bar = h('div', { class: 'filters' });
    const svc = h('select', { 'aria-label': 'Service' }); const sev = h('select', { 'aria-label': 'Minimum severity' }, ...[['', 'All levels'], ['DEBUG', 'Debug+'], ['INFO', 'Info+'], ['WARN', 'Warn+'], ['ERROR', 'Errors']].map(([v, t]) => h('option', { value: v, text: t }))); const search = h('input', { type: 'search', placeholder: 'Search log text' });
    bar.append(svc, sev, search); const vol = h('div'), body = h('div', { class: 'mt' }); el.append(bar, vol, body);
    let timer; const rerun = () => { clearTimeout(timer); timer = setTimeout(() => page.update(), 250); };
    svc.addEventListener('change', () => { f.service = svc.value; rerun(); }); sev.addEventListener('change', () => { f.severity = sev.value; rerun(); }); search.addEventListener('input', () => { f.q = search.value; rerun(); });
    const page = { title: 'Logs', el, async update() {
      const [ov, logs] = await Promise.all([api('/api/overview?' + q({ window: ui.range })), api('/api/logs?' + q({ window: ui.range, service: f.service, severity: f.severity, q: f.q }))]);
      const cur = svc.value || f.service; svc.replaceChildren(h('option', { value: '', text: 'All services' }), ...ov.services.map((x) => h('option', { value: x.name, text: x.name }))); svc.value = cur;
      const step = Math.max(5000, Math.round(({ '5m': 300, '15m': 900, '1h': 3600 }[ui.range] || 900) / 60) * 1000); const now = Date.now(); const n = 60; const t = [], er = [], wa = [], inf = []; const t0 = now - n * step;
      for (let i = 0; i <= n; i++) { t.push(t0 + i * step); er.push(0); wa.push(0); inf.push(0); }
      for (const l of logs) { const i = Math.floor((l.time - t0) / step); if (i < 0 || i > n) continue; const L = l.severity; if (L === 'ERROR' || L === 'FATAL') er[i]++; else if (L === 'WARN' || L === 'WARNING') wa[i]++; else inf[i]++; }
      const wT = wa.map((v, i) => v + inf[i]), eT = er.map((v, i) => v + wT[i]);
      vol.replaceChildren(card(`Log volume (${logs.length}${logs.length >= 500 ? '+' : ''} matching)`, timeChart({ t, series: [{ name: 'error', values: eT, tip: er, color: C.red, type: 'bars' }, { name: 'warn', values: wT, tip: wa, color: C.amber, type: 'bars' }, { name: 'info/debug', values: inf, tip: inf, color: C.blue, type: 'bars' }], height: 110, format: fmt.num, empty: 'No logs in this window' })));
      body.replaceChildren(card(null, logs.length ? logList(logs) : note(b('No logs received. '), 'The SDK forwards ', code('console.log/info/warn/error'), ' and pino/winston/bunyan output automatically. Run ', code('npx obs-kit doctor'), ' if you expected some.')));
    } };
    return page;
  }

  function metricsPage(params) {
    const f = { service: params.get('service') || '', q: '' }; const el = h('div'); const bar = h('div', { class: 'filters' }); const svc = h('select', { 'aria-label': 'Service' }); const search = h('input', { type: 'search', placeholder: 'Filter metric name' }); bar.append(svc, search); const grid = h('div', { class: 'grid g3' }); el.append(bar, grid);
    let timer; const rerun = () => { clearTimeout(timer); timer = setTimeout(() => page.update(), 250); }; svc.addEventListener('change', () => { f.service = svc.value; rerun(); }); search.addEventListener('input', () => { f.q = search.value; rerun(); });
    const page = { title: 'Metrics', el, async update() {
      const [ov, ms] = await Promise.all([api('/api/overview?' + q({ window: ui.range })), api('/api/metrics?' + q({ service: f.service, q: f.q }))]);
      const cur = svc.value || f.service; svc.replaceChildren(h('option', { value: '', text: 'All services' }), ...ov.services.map((x) => h('option', { value: x.name, text: x.name }))); svc.value = cur;
      ms.sort((a, c) => a.service.localeCompare(c.service) || a.name.localeCompare(c.name));
      if (!ms.length) { grid.replaceChildren(note(b('No metrics received. '), 'The SDK exports runtime metrics (CPU, memory, event loop) every 10 s plus whatever your libraries emit. Run ', code('npx obs-kit doctor'), ' to test the pipeline.')); return; }
      grid.replaceChildren(...ms.slice(0, 60).map((m) => { const c = metricCard(m, 90); c.querySelector('.card-h').append(h('span', { class: 'tag', text: m.service })); return c; }));
      if (ms.length > 60) grid.append(note(`Showing 60 of ${ms.length} series. Narrow with the filters above.`));
    } };
    return page;
  }

  function mapPage() {
    const el = h('div'); const box = h('div', { class: 'card' }); el.append(box);
    return { title: 'Service map', el, async update() {
      const [g, ov] = await Promise.all([api('/api/graph?' + q({ window: ui.range })), api('/api/overview?' + q({ window: ui.range }))]);
      const info = new Map(ov.services.map((x) => [x.name, x])); if (!g.nodes.length) { box.replaceChildren(onboarding(ui.info)); return; }
      const ids = g.nodes.map((n) => n.id); const depth = new Map(ids.map((i) => [i, 0])); for (let k = 0; k < ids.length; k++) { let ch = false; for (const e of g.edges) { const d = depth.get(e.from) + 1; if (d > depth.get(e.to) && d < ids.length) { depth.set(e.to, d); ch = true; } } if (!ch) break; }
      const cols = new Map(); for (const n of g.nodes) { const d = depth.get(n.id); if (!cols.has(d)) cols.set(d, []); cols.get(d).push(n); }
      const NW = 190, NH = 56, GX = 130, GY = 26, P = 24; const nCols = Math.max(...cols.keys()) + 1; const maxRows = Math.max(...[...cols.values()].map((c) => c.length));
      const W = P * 2 + nCols * NW + (nCols - 1) * GX, H = P * 2 + maxRows * NH + (maxRows - 1) * GY; const pos = new Map();
      for (const [d, list] of cols) { list.sort((a, c) => a.id.localeCompare(c.id)); const colH = list.length * NH + (list.length - 1) * GY; list.forEach((n, i) => pos.set(n.id, { x: P + d * (NW + GX), y: P + (H - P * 2 - colH) / 2 + i * (NH + GY) })); }
      const svg = s('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Service dependency map' }); svg.style.maxHeight = '70vh'; svg.style.minWidth = Math.min(W, 640) + 'px';
      const maxCalls = Math.max(1, ...g.edges.map((e) => e.calls));
      for (const e of g.edges) { const a = pos.get(e.from), c = pos.get(e.to); if (!a || !c) continue; const x1 = a.x + NW, y1 = a.y + NH / 2, x2 = c.x, y2 = c.y + NH / 2, mx = (x1 + x2) / 2;
        const p = s('path', { class: 'edge' + (e.errors / e.calls >= 0.05 ? ' bad' : ''), d: `M${x1} ${y1} C${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`, 'stroke-width': 1.5 + (e.calls / maxCalls) * 4 }, svg); p.setAttribute('opacity', '0.8');
        s('text', { class: 'elabel', x: mx, y: (y1 + y2) / 2 - 5, 'text-anchor': 'middle', text: `${fmt.num(e.calls)} calls · ${fmt.ms(e.avgMs)}` }, svg); }
      for (const n of g.nodes) { const p = pos.get(n.id); const sv = info.get(n.id); const dep = n.type !== 'service';
        const grp = s('g', { class: 'node ' + (dep ? 'dep' : sv ? sv.status : ''), transform: `translate(${p.x},${p.y})`, tabindex: dep ? '-1' : '0', role: dep ? 'img' : 'link', 'aria-label': n.id }, svg);
        s('rect', { width: NW, height: NH, rx: 10 }, grp); s('text', { x: 12, y: 22, text: (dep ? ({ database: '▤ ', queue: '⇄ ', external: '↗ ' }[n.type] || '') : '') + (n.id.length > 24 ? n.id.slice(0, 23) + '…' : n.id) }, grp);
        s('text', { class: 'sub', x: 12, y: 40, text: dep ? n.type : sv ? `${sv.status} · ${fmt.rate(sv.rps)} · p95 ${fmt.ms(sv.p95)}` : 'service' }, grp);
        if (!dep) { const open = () => { location.hash = '#/service/' + encodeURIComponent(n.id); }; grp.addEventListener('click', open); grp.addEventListener('keydown', (e) => { if (e.key === 'Enter') open(); }); } }
      const wrap = h('div', { class: 'graph' }, svg); box.replaceChildren(h('h3', {}, text('Dependencies'), text(g.edges.length ? '' : 'no cross-service calls observed yet')), wrap, h('p', { class: 'muted small', text: 'Edges come from trace context propagated between services, plus outbound database/HTTP calls. Dashed boxes are things that don’t report telemetry themselves.' }));
    } };
  }

  // ---------- router ----------
  function metaLine(info) { if (info) $('meta').textContent = `${fmt.num(info.counts.spans)} spans · ${fmt.num(info.counts.logs)} logs · ${fmt.num(info.counts.series)} series · v${info.appVersion || ''}`; }
  function parseHash() { const raw = location.hash.replace(/^#\/?/, ''); const [path, query = ''] = raw.split('?'); const seg = path.split('/').filter(Boolean).map((x) => { try { return decodeURIComponent(x); } catch { return x; } }); return { seg, params: new URLSearchParams(query) }; }
  async function route() {
    const { seg, params } = parseHash(); const id = seg[0] || 'overview'; const key = location.hash.split('?')[0] + '?' + (id === 'service' ? '' : params.toString());
    let page; if (id === 'service' && seg[1]) page = servicePage(seg[1]); else if (id === 'traces') { if (seg[1]) params.set('id', seg[1]); page = tracesPage(params); } else if (id === 'logs') page = logsPage(params); else if (id === 'metrics') page = metricsPage(params); else if (id === 'map') page = mapPage(); else page = overviewPage();
    ui.page = page; ui.key = key; $('title').textContent = page.title; document.title = page.title + ' · obs-kit';
    for (const a of $('nav').children) a.classList.toggle('on', a.dataset.id === (id === 'service' ? 'overview' : id));
    $('view').replaceChildren(page.el); window.scrollTo(0, 0); refresh();
  }
  let busy = false, again = false;
  async function refresh() {
    if (!ui.page) return; if (busy) { again = true; return; } busy = true;
    try { await ui.page.update(); } catch (e) { if (e.message !== 'auth') { const v = $('view'); if (!v.querySelector('.err-note')) v.prepend(h('div', { class: 'note warn err-note', text: 'Could not refresh: ' + e.message })); } } finally { busy = false; if (again) { again = false; refresh(); } }
    const n = document.querySelector('.err-note'); if (n && !busy) n.remove();
  }
  window.addEventListener('hashchange', () => { if ($('app').hidden) return; route(); });
  window.addEventListener('visibilitychange', () => { if (!document.hidden && !ui.paused) refresh(); });

  buildNav();
  fetch('/api/session', { credentials: 'same-origin' }).then((r) => r.json()).then((j) => (j.authed ? showApp() : showLogin())).catch(showLogin);
})();
