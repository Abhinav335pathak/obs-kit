'use strict';
// Dependency-free SVG charts. CSP-safe: colors/sizes are applied through the CSSOM / attributes, never inline style markup.
// All text is written with textContent; telemetry is never interpreted as HTML.
(function () {
  const NS = 'http://www.w3.org/2000/svg';
  const h = (tag, attrs, ...kids) => { const e = document.createElement(tag); for (const [k, v] of Object.entries(attrs || {})) { if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v; else e.setAttribute(k, v); } for (const c of kids) if (c) e.append(c); return e; };
  const s = (tag, attrs, parent) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs || {})) { if (k === 'text') e.textContent = v; else if (k === 'class') e.setAttribute('class', v); else e.setAttribute(k, v); } if (parent) parent.append(e); return e; };
  const paint = (el, prop, color) => { el.style.setProperty(prop, color); };

  const fmt = {
    ms(n) { if (!Number.isFinite(n)) return '–'; if (n >= 60000) return (n / 60000).toFixed(1) + ' min'; if (n >= 1000) return (n / 1000).toFixed(2) + ' s'; if (n >= 10) return n.toFixed(0) + ' ms'; return n.toFixed(n >= 1 ? 1 : 2) + ' ms'; },
    num(n) { if (!Number.isFinite(n)) return '–'; const a = Math.abs(n); if (a >= 1e9) return (n / 1e9).toFixed(1) + 'B'; if (a >= 1e6) return (n / 1e6).toFixed(1) + 'M'; if (a >= 1e4) return (n / 1e3).toFixed(1) + 'k'; if (Number.isInteger(n)) return String(n); if (a >= 100) return n.toFixed(0); if (a >= 10) return n.toFixed(1); if (a === 0) return '0'; return n.toFixed(2); },
    rate(n) { return Number.isFinite(n) ? (n >= 100 ? n.toFixed(0) : n >= 10 ? n.toFixed(1) : n.toFixed(2)) + '/s' : '–'; },
    pct(n) { return Number.isFinite(n) ? (n * 100 >= 10 ? (n * 100).toFixed(0) : (n * 100).toFixed(1)) + '%' : '–'; },
    bytes(n) { if (!Number.isFinite(n)) return '–'; const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; while (Math.abs(n) >= 1024 && i < u.length - 1) { n /= 1024; i++; } return (i ? n.toFixed(n >= 100 ? 0 : 1) : n.toFixed(0)) + ' ' + u[i]; },
    time(t, withSec) { const d = new Date(t); const p = (x) => String(x).padStart(2, '0'); return p(d.getHours()) + ':' + p(d.getMinutes()) + (withSec ? ':' + p(d.getSeconds()) : ''); },
    ago(t) { if (!t) return 'never'; const d = Math.max(0, Date.now() - t) / 1000; if (d < 5) return 'just now'; if (d < 60) return Math.round(d) + 's ago'; if (d < 3600) return Math.round(d / 60) + 'm ago'; if (d < 86400) return Math.round(d / 3600) + 'h ago'; return Math.round(d / 86400) + 'd ago'; },
    // pick a formatter from a metric's unit
    byUnit(unit) { const u = String(unit || ''); if (u === 'By') return fmt.bytes; if (u === 'ms') return fmt.ms; if (u === 's') return (n) => fmt.ms(n * 1000); if (u === '1' || u === '') return fmt.num; if (u.endsWith('/s')) return fmt.num; return fmt.num; },
  };

  function niceScale(min, max, ticks = 4) {
    if (!Number.isFinite(min) || !Number.isFinite(max)) { min = 0; max = 1; }
    if (max <= min) max = min + (Math.abs(min) || 1);
    const span = max - min; const raw = span / ticks; const mag = Math.pow(10, Math.floor(Math.log10(raw))); const err = raw / mag;
    const step = (err >= 7.5 ? 10 : err >= 3.5 ? 5 : err >= 1.5 ? 2 : 1) * mag;
    const lo = Math.floor(min / step) * step; const hi = Math.ceil(max / step) * step; const out = [];
    for (let v = lo; v <= hi + step / 2; v += step) out.push(+v.toFixed(10));
    return { lo, hi, ticks: out };
  }

  // Generic time-series chart. series: [{name, values, color, type: 'line'|'area'|'bars', dash}]
  function timeChart({ t, series, height = 180, format = fmt.num, min = 0, max, empty = 'No data in this window', fixedMax }) {
    const wrap = h('div', { class: 'chart' });
    const width = Math.max(260, Math.floor(wrap.clientWidth || 640));
    const draw = (w) => {
      wrap.replaceChildren();
      const M = { l: 46, r: 10, t: 8, b: 20 }; const W = w, H = height; const iw = W - M.l - M.r, ih = H - M.t - M.b;
      const all = series.flatMap((x) => x.values.filter(Number.isFinite)); const hasData = all.length && t && t.length > 1 && all.some((v) => v !== 0);
      let lo = min, hi = max !== undefined ? max : Math.max(...all, 0);
      if (fixedMax !== undefined) hi = Math.max(hi, fixedMax);
      const sc = niceScale(lo, hi <= lo ? lo + 1 : hi, Math.max(2, Math.floor((H - M.t - M.b) / 38)));
      const svg = s('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, role: 'img', 'aria-label': series.map((x) => x.name).join(', ') });
      const x = (i) => M.l + (t.length > 1 ? (i / (t.length - 1)) * iw : 0); const y = (v) => M.t + ih - ((v - sc.lo) / (sc.hi - sc.lo || 1)) * ih;
      for (const tk of sc.ticks) { s('line', { class: 'grid', x1: M.l, x2: W - M.r, y1: y(tk), y2: y(tk) }, svg); s('text', { class: 'axis', x: M.l - 6, y: y(tk) + 3.5, 'text-anchor': 'end', text: format(tk) }, svg); }
      if (t && t.length > 1) {
        const n = Math.max(2, Math.min(6, Math.floor(iw / 90))); const spanMs = t[t.length - 1] - t[0];
        for (let k = 0; k < n; k++) { const i = Math.round((k / (n - 1)) * (t.length - 1)); s('text', { class: 'axis', x: x(i), y: H - 5, 'text-anchor': k === 0 ? 'start' : k === n - 1 ? 'end' : 'middle', text: fmt.time(t[i], spanMs < 20 * 60000) }, svg); }
      }
      if (hasData) {
        for (const se of series) {
          const pts = se.values.map((v, i) => [x(i), y(Number.isFinite(v) ? v : 0)]);
          if (se.type === 'bars') { const bw = Math.max(1, iw / t.length - 1); pts.forEach(([px, py], i) => { if (se.values[i] > 0) { const r = s('rect', { x: px - bw / 2, y: py, width: bw, height: Math.max(0, M.t + ih - py), rx: 1 }, svg); paint(r, 'fill', se.color); r.style.opacity = '0.85'; } }); continue; }
          const d = pts.map(([px, py], i) => (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1)).join(' ');
          if (se.type === 'area') { const a = s('path', { d: d + ` L${pts[pts.length - 1][0].toFixed(1)} ${y(sc.lo)} L${pts[0][0].toFixed(1)} ${y(sc.lo)} Z`, class: 'area' }, svg); paint(a, 'fill', se.color); }
          const l = s('path', { d, class: 'line' }, svg); paint(l, 'stroke', se.color); if (se.dash) l.setAttribute('stroke-dasharray', se.dash);
        }
      } else s('text', { class: 'empty', x: W / 2, y: H / 2, 'text-anchor': 'middle', text: empty }, svg);
      wrap.append(svg);
      if (hasData) {
        const cross = s('line', { class: 'cross', y1: M.t, y2: M.t + ih, x1: 0, x2: 0, visibility: 'hidden' }, svg);
        const dots = series.map((se) => { const c = s('circle', { r: 3.5, visibility: 'hidden' }, svg); paint(c, 'fill', se.color); return c; });
        const tip = h('div', { class: 'tip', hidden: '' }); wrap.append(tip);
        const overlay = s('rect', { x: M.l, y: M.t, width: iw, height: ih, fill: 'transparent' }, svg);
        overlay.addEventListener('pointermove', (ev) => {
          const r = overlay.getBoundingClientRect(); const rel = (ev.clientX - r.left) / r.width; const i = Math.max(0, Math.min(t.length - 1, Math.round(rel * (t.length - 1))));
          cross.setAttribute('x1', x(i)); cross.setAttribute('x2', x(i)); cross.setAttribute('visibility', 'visible');
          series.forEach((se, k) => { dots[k].setAttribute('cx', x(i)); dots[k].setAttribute('cy', y(se.values[i] || 0)); dots[k].setAttribute('visibility', 'visible'); });
          tip.replaceChildren(h('div', { class: 'tip-t', text: fmt.time(t[i], true) }), ...series.map((se) => { const row = h('div', { class: 'tip-r' }); const sw = h('i'); paint(sw, 'background', se.color); row.append(sw, h('span', { text: se.name }), h('b', { text: (se.format || format)((se.tip || se.values)[i] || 0) })); return row; }));
          tip.hidden = false; const px = (x(i) / W) * wrap.clientWidth; tip.style.left = Math.min(Math.max(px + 12, 0), wrap.clientWidth - tip.offsetWidth - 4) + 'px'; tip.style.top = '6px';
        });
        overlay.addEventListener('pointerleave', () => { cross.setAttribute('visibility', 'hidden'); dots.forEach((d) => d.setAttribute('visibility', 'hidden')); tip.hidden = true; });
      }
    };
    wrap.__draw = draw; wrap.__w = width; draw(width);
    // resize once attached and whenever the container changes width
    if (typeof ResizeObserver !== 'undefined') { let last = 0; new ResizeObserver(() => { const w = Math.floor(wrap.clientWidth); if (w > 0 && Math.abs(w - last) > 4) { last = w; draw(w); } }).observe(wrap); }
    return wrap;
  }

  function legend(items) { const l = h('div', { class: 'legend' }); for (const it of items) { const i = h('i'); paint(i, 'background', it.color); l.append(h('span', {}, i, document.createTextNode(it.name))); } return l; }

  function sparkline(values, color, w = 96, hgt = 26) {
    const svg = s('svg', { class: 'spark', viewBox: `0 0 ${w} ${hgt}`, width: w, height: hgt, 'aria-hidden': 'true' });
    const v = (values || []).map((n) => (Number.isFinite(n) ? n : 0)); if (v.length < 2 || v.every((n) => n === 0)) { s('line', { class: 'spark-flat', x1: 1, x2: w - 1, y1: hgt - 2, y2: hgt - 2 }, svg); return svg; }
    const lo = Math.min(...v, 0), hi = Math.max(...v); const sp = hi - lo || 1;
    const pts = v.map((n, i) => [1 + (i / (v.length - 1)) * (w - 2), hgt - 2 - ((n - lo) / sp) * (hgt - 5)]);
    const d = pts.map(([px, py], i) => (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1)).join(' ');
    const a = s('path', { d: d + ` L${w - 1} ${hgt - 2} L1 ${hgt - 2} Z`, class: 'area' }, svg); paint(a, 'fill', color);
    const l = s('path', { d, class: 'line' }, svg); paint(l, 'stroke', color); return svg;
  }

  window.Charts = { h, s, paint, fmt, niceScale, timeChart, legend, sparkline };
})();
