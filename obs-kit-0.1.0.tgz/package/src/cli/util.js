'use strict';
const fs = require('fs');
const path = require('path');
const net = require('net');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const PKG_ROOT = path.resolve(__dirname, '..', '..');
const pkg = (() => { try { return require(path.join(PKG_ROOT, 'package.json')); } catch { return { version: '0.0.0' }; } })();
const CONFIG_NAME = 'obs-kit.config.json';

// ---- output ----
const useColor = process.stdout.isTTY && !process.env.NO_COLOR;
const c = (n, s) => (useColor ? `\x1b[${n}m${s}\x1b[0m` : String(s));
const fmt = { bold: (s) => c(1, s), dim: (s) => c(2, s), red: (s) => c(31, s), green: (s) => c(32, s), yellow: (s) => c(33, s), cyan: (s) => c(36, s) };
const sym = { ok: fmt.green('✓'), bad: fmt.red('✗'), warn: fmt.yellow('!'), arrow: fmt.green('➜') };
const out = (...a) => console.log(...a);

class CliError extends Error { constructor(msg, hint) { super(msg); this.hint = hint; } }

// ---- project / config ----
function findRoot(start) {
  let d = path.resolve(start);
  for (;;) { if (fs.existsSync(path.join(d, CONFIG_NAME))) return d; const p = path.dirname(d); if (p === d) return path.resolve(start); d = p; }
}
const paths = (root) => { const dir = path.join(root, '.obs-kit'); return { root, dir, config: path.join(root, CONFIG_NAME), state: path.join(dir, 'state.json'), secrets: path.join(dir, 'secrets.json'), viewerLog: path.join(dir, 'viewer.log'), appLog: (n) => path.join(dir, `app-${n}.log`) }; };
const readJson = (f, d = null) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
function writeJson(f, v, mode) { fs.mkdirSync(path.dirname(f), { recursive: true, mode: 0o700 }); fs.writeFileSync(f, JSON.stringify(v, null, 2) + '\n', { mode: mode || 0o644 }); if (mode) { try { fs.chmodSync(f, mode); } catch { /* windows */ } } }

const DEFAULTS = { serviceName: null, serviceType: 'auto', command: null, ui: { port: 7800 }, ingest: { port: 4320 }, retentionMinutes: 60, endpoint: null, env: {}, services: [] };
function loadConfig(root) { const f = readJson(paths(root).config, {}); return { ...DEFAULTS, ...f, ui: { ...DEFAULTS.ui, ...f.ui }, ingest: { ...DEFAULTS.ingest, ...f.ingest } }; }

function ensureSecrets(root) {
  const p = paths(root); let s = readJson(p.secrets);
  if (!s || !s.ingestToken || !s.ownerPassword || !s.sessionSecret) {
    s = { ingestToken: crypto.randomBytes(24).toString('base64url'), ownerPassword: crypto.randomBytes(12).toString('base64url'), sessionSecret: crypto.randomBytes(32).toString('hex'), ...(s || {}) };
    writeJson(p.secrets, s, 0o600);
  }
  return s;
}
function ensureGitignore(root) {
  const f = path.join(root, '.gitignore'); let body = ''; try { body = fs.readFileSync(f, 'utf8'); } catch { /* none */ }
  if (/^\/?\.obs-kit\/?$/m.test(body)) return false;
  fs.writeFileSync(f, body + (body && !body.endsWith('\n') ? '\n' : '') + '# obs-kit local state (contains secrets)\n.obs-kit/\n'); return true;
}

function detectProject(dir) {
  const has = (f) => fs.existsSync(path.join(dir, f)); const pj = readJson(path.join(dir, 'package.json'));
  let lang = 'unknown', command = null, name = path.basename(dir);
  if (pj) {
    lang = 'node'; name = String(pj.name || name).replace(/^@[^/]+\//, '');
    if (pj.scripts?.start) command = 'npm start'; else if (pj.scripts?.dev) command = 'npm run dev';
    else if (pj.main && has(pj.main)) command = `node ${pj.main}`; else for (const f of ['server.js', 'index.js', 'app.js', 'src/index.js', 'main.js']) if (has(f)) { command = `node ${f}`; break; }
  } else if (has('requirements.txt') || has('pyproject.toml') || has('manage.py') || has('Pipfile')) {
    lang = 'python'; if (has('manage.py')) command = 'python manage.py runserver'; else for (const f of ['main.py', 'app.py', 'server.py']) if (has(f)) { command = `python ${f}`; break; }
  } else if (has('go.mod')) { lang = 'go'; command = 'go run .'; }
  else if (has('pom.xml')) { lang = 'java'; command = null; } else if (has('build.gradle') || has('build.gradle.kts')) { lang = 'java'; command = null; }
  else if (has('Cargo.toml')) { lang = 'rust'; command = 'cargo run'; } else if (has('Gemfile')) { lang = 'ruby'; command = null; }
  else if ([...(fs.existsSync(dir) ? fs.readdirSync(dir) : [])].some((f) => /\.(csproj|sln)$/.test(f))) { lang = 'dotnet'; command = 'dotnet run'; }
  return { lang, command, name, pkg: pj };
}
// Subfolders that look like separate services (for monorepos / microservice workspaces)
function detectWorkspace(root) {
  const found = []; const skip = new Set(['node_modules', '.git', '.obs-kit', 'dist', 'build', 'coverage', 'vendor']);
  const scan = (dir, depth) => {
    let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of ents) { if (!e.isDirectory() || skip.has(e.name) || e.name.startsWith('.')) continue; const d = path.join(dir, e.name); const p = detectProject(d);
      if (p.lang !== 'unknown' && p.command) found.push({ name: p.name, cwd: path.relative(root, d) || '.', command: p.command, lang: p.lang }); else if (depth < 2) scan(d, depth + 1); }
  };
  scan(root, 1); return found;
}

// ---- processes ----
function isAlive(pid) { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } }
// Guard against PID reuse: before signalling a recorded pid, confirm (where /proc exists) that its
// command line still contains what we launched. Elsewhere we can only check that it is alive.
function pidMatches(pid, needle) {
  if (!isAlive(pid)) return false; if (!needle) return true;
  try { return fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8').replace(/\0/g, ' ').includes(needle); } catch { return true; }
}
function killTree(pid, signal = 'SIGTERM') {
  try {
    if (process.platform === 'win32') execFileSync('taskkill', ['/pid', String(pid), '/T', ...(signal === 'SIGKILL' ? ['/F'] : [])], { stdio: 'ignore' });
    else { try { process.kill(-pid, signal); } catch { process.kill(pid, signal); } }
    return true;
  } catch { return false; }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(fn, ms, step = 100) { const end = Date.now() + ms; while (Date.now() < end) { if (await fn()) return true; await sleep(step); } return false; }

function portFree(port, host = '127.0.0.1') { return new Promise((res) => { const s = net.createServer(); s.once('error', () => res(false)); s.listen(port, host, () => s.close(() => res(true))); }); }
async function freePort(preferred, avoid = []) { for (let p = preferred; p < preferred + 50; p++) if (!avoid.includes(p) && await portFree(p)) return p; throw new CliError(`no free port near ${preferred}`, 'set ui.port / ingest.port in obs-kit.config.json'); }

// ---- http ----
function request(url, { method = 'GET', headers = {}, body, timeout = 4000, ca } = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url); const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request(u, { method, headers, timeout, ...(ca ? { ca } : {}) }, (res) => { const ch = []; res.on('data', (d) => ch.push(d)); res.on('end', () => { const text = Buffer.concat(ch).toString('utf8'); let json = null; try { json = JSON.parse(text); } catch { /* not json */ } resolve({ status: res.statusCode, headers: res.headers, text, json }); }); });
    req.on('timeout', () => req.destroy(new Error('timeout'))); req.on('error', reject); if (body) req.write(body); req.end();
  });
}

function openBrowser(url) {
  try { const [cmd, args] = process.platform === 'darwin' ? ['open', [url]] : process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : ['xdg-open', [url]]; require('child_process').spawn(cmd, args, { stdio: 'ignore', detached: true }).on('error', () => {}).unref(); return true; } catch { return false; }
}

function parseArgs(argv) {
  const flags = {}; const rest = []; const dd = argv.indexOf('--'); const before = dd === -1 ? argv : argv.slice(0, dd); const after = dd === -1 ? [] : argv.slice(dd + 1);
  for (let i = 0; i < before.length; i++) {
    const a = before[i];
    if (a.startsWith('--')) { const [k, v] = a.slice(2).split('='); if (v !== undefined) flags[k] = v; else if (before[i + 1] && !before[i + 1].startsWith('-') && ['name', 'type', 'command', 'endpoint', 'token', 'ui-port', 'ingest-port', 'host', 'service'].includes(k)) flags[k] = before[++i]; else flags[k] = true; }
    else if (a.startsWith('-') && a.length > 1) { for (const ch of a.slice(1)) flags[{ y: 'yes', h: 'help', v: 'version', d: 'detach' }[ch] || ch] = true; } else rest.push(a);
  }
  return { flags, rest, passthrough: after };
}

module.exports = { PKG_ROOT, pkg, CONFIG_NAME, fmt, sym, out, CliError, findRoot, paths, readJson, writeJson, loadConfig, ensureSecrets, ensureGitignore, detectProject, detectWorkspace, isAlive, pidMatches, killTree, sleep, waitFor, portFree, freePort, request, openBrowser, parseArgs, DEFAULTS };
