'use strict';
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { spawnSync } = require('child_process');
const U = require('../util');
const { fmt, sym, out } = U;

function ask(q, def) {
  if (!process.stdin.isTTY) return Promise.resolve(def);
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((res) => rl.question(`  ${q}${def ? fmt.dim(` (${def})`) : ''}: `, (a) => { rl.close(); res(a.trim() || def); }));
}

const HINTS = {
  node: (n) => [`${fmt.bold('Node.js')}: nothing else to do. ${fmt.cyan('npx obs-kit start')} injects the SDK into ${n}, no code changes.`,
    `For production/deploys add the package and preload it: ${fmt.cyan('npm i obs-kit')}  then  ${fmt.cyan('node -r obs-kit/register server.js')}`,
    `or call ${fmt.cyan("require('obs-kit/sdk').initObservability()")} as the first line of your entrypoint.`],
  python: () => [`${fmt.bold('Python')}: ${fmt.cyan('pip install opentelemetry-distro opentelemetry-exporter-otlp')}`, `then ${fmt.cyan('npx obs-kit start -- opentelemetry-instrument python app.py')}  (obs-kit sets the OTEL_* variables)`],
  java: () => [`${fmt.bold('Java')}: download the OpenTelemetry Java agent, then ${fmt.cyan('npx obs-kit start -- java -javaagent:opentelemetry-javaagent.jar -jar app.jar')}`],
  go: () => [`${fmt.bold('Go')}: use the OpenTelemetry Go SDK with the ${fmt.cyan('otlptracehttp / otlpmetrichttp / otlploghttp')} exporters (they read the OTEL_* variables obs-kit sets). gRPC exporters need an OpenTelemetry Collector in front.`],
  dotnet: () => [`${fmt.bold('.NET')}: add ${fmt.cyan('OpenTelemetry.Extensions.Hosting')} + ${fmt.cyan('OpenTelemetry.Exporter.OpenTelemetryProtocol')} with the HTTP/protobuf protocol; it reads the OTEL_* variables.`],
  other: () => [`${fmt.bold('Any language')}: use its OpenTelemetry SDK with OTLP over HTTP (protobuf or JSON). obs-kit start sets ${fmt.cyan('OTEL_EXPORTER_OTLP_ENDPOINT / _HEADERS / OTEL_SERVICE_NAME')} for the process.`],
};

async function init({ flags }) {
  const root = process.cwd(); const P = U.paths(root); const exists = fs.existsSync(P.config);
  const det = U.detectProject(root); let existing = exists ? U.readJson(P.config, {}) : {};
  out(`\n  ${fmt.bold('obs-kit init')} ${fmt.dim(root)}\n`);
  if (exists && !flags.force) out(`  ${sym.ok}  ${U.CONFIG_NAME} already exists ${fmt.dim('(use --force to regenerate)')}`);
  else {
    const ws = (det.lang === 'unknown' || flags.workspace) ? U.detectWorkspace(root) : [];
    let cfg;
    if (ws.length >= 2) {
      out(`  ${sym.ok}  Detected a workspace with ${ws.length} services:`); for (const s of ws) out(`       ${fmt.bold(s.name.padEnd(18))} ${fmt.dim(s.cwd + '  →  ' + s.command)}`);
      cfg = { services: ws.map(({ name, cwd, command }) => ({ name, cwd, command })) };
    } else {
      const name = flags.name || await ask('Service name', det.name); const command = flags.command || await ask('Command that starts it', det.command || '');
      cfg = { serviceName: name, ...(flags.type ? { serviceType: flags.type } : {}), ...(command ? { command } : {}) };
      if (!command) out(`  ${sym.warn}  No start command detected. Set "command" in ${U.CONFIG_NAME}, or pass one: ${fmt.cyan('npx obs-kit start -- <command>')}`);
    }
    cfg = { ...cfg, ui: { port: 7800 }, ingest: { port: 4320 }, retentionMinutes: 60 };
    U.writeJson(P.config, cfg); out(`  ${sym.ok}  wrote ${U.CONFIG_NAME} ${fmt.dim('(safe to commit: contains no secrets)')}`); existing = cfg;
  }
  U.ensureSecrets(root); out(`  ${sym.ok}  generated local credentials in .obs-kit/secrets.json ${fmt.dim('(mode 600)')}`);
  if (U.ensureGitignore(root)) out(`  ${sym.ok}  added .obs-kit/ to .gitignore`);

  if (det.lang === 'node' && flags.install) {
    const has = det.pkg && ({ ...det.pkg.dependencies, ...det.pkg.devDependencies })['obs-kit'];
    if (has) out(`  ${sym.ok}  obs-kit is already a dependency`);
    else { out(`  ${fmt.dim('running npm install obs-kit …')}`); const r = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install', 'obs-kit'], { cwd: root, stdio: 'inherit' }); out(r.status === 0 ? `  ${sym.ok}  installed obs-kit` : `  ${sym.bad}  npm install failed (exit ${r.status}); run it yourself when online`); }
  }
  out(`\n  ${fmt.bold('Next')}\n    ${fmt.cyan('npx obs-kit start')}      run monitoring + your app\n    ${fmt.cyan('npx obs-kit dashboard')}  get the dashboard URL\n    ${fmt.cyan('npx obs-kit doctor')}     check everything works\n`);
  const lang = (existing.services && existing.services.length) ? 'node' : det.lang; const hint = (HINTS[lang] || HINTS.other)(det.name);
  out(`  ${fmt.bold('Language notes')}`); for (const l of hint) out(`    ${l}`); out('');
  return 0;
}
module.exports = { init };
