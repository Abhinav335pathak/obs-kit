'use strict';
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');
const U = require('../util');
const { fmt, sym, out, CliError } = U;
const auth = require('../../viewer/auth');

const SERVER = path.join(U.PKG_ROOT, 'src', 'viewer', 'server.js');
const REGISTER = path.join(U.PKG_ROOT, 'src', 'sdk', 'register.js');
const ESM_REGISTER = path.join(U.PKG_ROOT, 'src', 'sdk', 'esm-register.mjs');

/** Environment that turns on telemetry for ANY program: our Node SDK reads OBS_*, every other OpenTelemetry SDK reads OTEL_*. */
function buildAppEnv({ svc, endpoint, token, cfg, base = process.env, lang }) {
  const env = { ...base, ...cfg.env, ...(svc.env || {}) };
  const ver = process.versions.node.split('.').map(Number);
  const quote = (p) => JSON.stringify(p);
  let nodeOpts = `--require ${quote(REGISTER)}`;
  if ((ver[0] > 20 || (ver[0] === 20 && ver[1] >= 6)) && hasIitm()) nodeOpts += ` --import ${quote(pathToFileURL(ESM_REGISTER).href)}`;
  env.NODE_OPTIONS = [nodeOpts, base.NODE_OPTIONS].filter(Boolean).join(' ');
  Object.assign(env, {
    OBS_SERVICE_NAME: svc.name, OBS_SERVICE_TYPE: svc.type || cfg.serviceType || 'auto', OBS_ENDPOINT: endpoint, OBS_ENVIRONMENT: env.OBS_ENVIRONMENT || 'development',
    OTEL_SERVICE_NAME: svc.name, OTEL_EXPORTER_OTLP_ENDPOINT: endpoint, OTEL_EXPORTER_OTLP_PROTOCOL: 'http/protobuf', OTEL_METRIC_EXPORT_INTERVAL: '10000',
    OTEL_RESOURCE_ATTRIBUTES: [`deployment.environment.name=${env.OBS_ENVIRONMENT}`, base.OTEL_RESOURCE_ATTRIBUTES].filter(Boolean).join(','),
  });
  if (token) { env.OBS_TOKEN = token; env.OTEL_EXPORTER_OTLP_HEADERS = `Authorization=Bearer%20${token}`; }
  if (lang === 'python') env.OTEL_PYTHON_LOGGING_AUTO_INSTRUMENTATION_ENABLED = 'true';
  return env;
}
function hasIitm() { try { require.resolve('import-in-the-middle/hook.mjs', { paths: [U.PKG_ROOT] }); return true; } catch { return false; } }

function resolveServices(root, cfg, flags, passthrough, names) {
  if (passthrough.length) { const p = U.detectProject(root); return [{ name: flags.name || cfg.serviceName || p.name, cwd: root, command: passthrough.join(' '), lang: p.lang }]; }
  if (cfg.services && cfg.services.length) {
    let list = cfg.services.map((s) => ({ ...s, cwd: path.resolve(root, s.cwd || '.'), lang: U.detectProject(path.resolve(root, s.cwd || '.')).lang }));
    if (names.length) { const miss = names.filter((n) => !list.some((s) => s.name === n)); if (miss.length) throw new CliError(`unknown service: ${miss.join(', ')}`, `known: ${list.map((s) => s.name).join(', ')}`); list = list.filter((s) => names.includes(s.name)); }
    return list;
  }
  const p = U.detectProject(root); const command = flags.command || cfg.command || p.command;
  return [{ name: flags.name || cfg.serviceName || p.name, cwd: root, command, lang: p.lang }];
}

async function ensureViewer(root, cfg, secrets, flags) {
  const P = U.paths(root); const state = U.readJson(P.state, {});
  const v = state.viewer;
  if (v && U.pidMatches(v.pid, 'viewer/server.js')) {
    const h = await U.request(`http://127.0.0.1:${v.ingestPort}/healthz`).catch(() => null);
    if (h && h.status === 200) return { ...v, reused: true };
  }
  const host = flags.host || '127.0.0.1';
  const uiPort = await U.freePort(Number(flags['ui-port'] || cfg.ui.port));
  const ingestPort = await U.freePort(Number(flags['ingest-port'] || cfg.ingest.port), [uiPort]);
  fs.mkdirSync(P.dir, { recursive: true, mode: 0o700 });
  const fd = fs.openSync(P.viewerLog, 'a', 0o600);
  const child = spawn(process.execPath, [SERVER], { detached: true, stdio: ['ignore', fd, fd], windowsHide: true, env: {
    ...process.env, OBS_VIEWER_HOST: host, OBS_UI_PORT: String(uiPort), OBS_INGEST_PORT: String(ingestPort), OBS_INGEST_TOKENS: secrets.ingestToken,
    OBS_OWNER_PASSWORD_HASH: auth.hashPassword(secrets.ownerPassword), OBS_SESSION_SECRET: secrets.sessionSecret, OBS_RETENTION_MIN: String(cfg.retentionMinutes) } });
  child.unref();
  const up = await U.waitFor(async () => { const h = await U.request(`http://127.0.0.1:${ingestPort}/healthz`, { timeout: 500 }).catch(() => null); return h && h.status === 200; }, 10000);
  if (!up) { let tail = ''; try { tail = fs.readFileSync(P.viewerLog, 'utf8').split('\n').slice(-6).join('\n'); } catch { /* none */ } throw new CliError('viewer did not start', `see ${path.relative(process.cwd(), P.viewerLog)}\n${tail}`); }
  const rec = { pid: child.pid, uiPort, ingestPort, host, startedAt: Date.now() };
  U.writeJson(P.state, { ...state, viewer: rec }); return { ...rec, reused: false };
}

async function start({ flags, rest, passthrough }) {
  const root = U.findRoot(process.cwd()); const cfg = U.loadConfig(root); const P = U.paths(root);
  const remote = flags.endpoint || cfg.endpoint; const secrets = U.ensureSecrets(root);
  const services = flags['viewer-only'] ? [] : resolveServices(root, cfg, flags, passthrough, rest);
  let endpoint, token, viewer = null;
  if (remote) { endpoint = String(remote).replace(/\/$/, ''); token = flags.token || process.env.OBS_TOKEN || ''; out(`\n  ${fmt.bold('obs-kit')} ${fmt.dim('v' + U.pkg.version)}\n\n  ${sym.arrow}  Sending telemetry to ${fmt.cyan(endpoint)}${token ? '' : fmt.yellow('  (no token: set OBS_TOKEN or --token)')}`); }
  else {
    viewer = await ensureViewer(root, cfg, secrets, flags);
    endpoint = `http://127.0.0.1:${viewer.ingestPort}`; token = secrets.ingestToken;
    const shownHost = viewer.host === '0.0.0.0' ? '<this-host>' : viewer.host;
    out(`\n  ${fmt.bold('obs-kit')} ${fmt.dim('v' + U.pkg.version)}  ${viewer.reused ? fmt.dim('(viewer already running)') : ''}\n`);
    out(`  ${sym.arrow}  ${fmt.bold('Dashboard:')} ${fmt.cyan(`http://${shownHost}:${viewer.uiPort}/`)}`);
    out(`  ${sym.arrow}  ${fmt.bold('Ingest:   ')} ${fmt.dim(endpoint + '  (OTLP/HTTP, bearer token required)')}`);
    out(`  ${fmt.dim('Run `npx obs-kit dashboard` for a one-click sign-in link.')}`);
    if (viewer.host !== '127.0.0.1') out(`  ${sym.warn}  Viewer is listening on ${viewer.host} without TLS: put it behind a VPN / TLS proxy.`);
  }
  if (flags['viewer-only']) { out(''); return 0; }
  if (!services.length || services.some((s) => !s.command)) {
    const missing = services.filter((s) => !s.command).map((s) => s.name);
    out(`\n  ${sym.warn}  ${missing.length ? `No start command found for: ${missing.join(', ')}.` : 'Nothing to run.'}`);
    out(`     Use ${fmt.cyan('npx obs-kit start -- <your command>')} or set "command" in ${U.CONFIG_NAME}. The viewer keeps running.\n`); return missing.length ? 1 : 0;
  }
  const multi = services.length > 1; const detach = !!flags.detach; const children = []; const apps = [];
  out(`\n  ${sym.ok}  Starting ${services.map((s) => fmt.bold(s.name)).join(', ')}${detach ? ' in the background' : ''}\n`);
  const colors = [36, 35, 33, 32, 34, 31]; const width = Math.max(...services.map((s) => s.name.length));
  services.forEach((svc, i) => {
    const env = buildAppEnv({ svc, endpoint, token, cfg, lang: svc.lang });
    const opts = { cwd: svc.cwd, env, shell: true, windowsHide: true };
    let child;
    if (detach) { const fd = fs.openSync(P.appLog(svc.name.replace(/[^\w.-]/g, '_')), 'a', 0o600); child = spawn(svc.command, [], { ...opts, detached: process.platform !== 'win32', stdio: ['ignore', fd, fd] }); child.unref(); }
    else if (multi) { child = spawn(svc.command, [], { ...opts, stdio: ['ignore', 'pipe', 'pipe'] }); const tag = U.fmt.bold(`\x1b[${colors[i % colors.length]}m${svc.name.padEnd(width)} |\x1b[0m`.replace(/\x1b\[[\d;]*m/g, (m) => (process.stdout.isTTY && !process.env.NO_COLOR ? m : '')));
      for (const [stream, sink] of [[child.stdout, process.stdout], [child.stderr, process.stderr]]) { let buf = ''; stream.on('data', (d) => { buf += d; const lines = buf.split('\n'); buf = lines.pop(); for (const l of lines) sink.write(`${tag} ${l}\n`); }); stream.on('end', () => { if (buf) sink.write(`${tag} ${buf}\n`); }); } }
    else child = spawn(svc.command, [], { ...opts, stdio: 'inherit' });
    child.on('error', (e) => out(`  ${sym.bad}  ${svc.name}: ${e.message}`));
    children.push({ svc, child }); apps.push({ name: svc.name, pid: child.pid, command: svc.command, mode: detach ? 'detached' : 'foreground', startedAt: Date.now() });
  });
  const state = U.readJson(P.state, {}); U.writeJson(P.state, { ...state, cliPid: detach ? undefined : process.pid, apps: [...(state.apps || []).filter((a) => !apps.some((n) => n.name === a.name)), ...apps] });
  if (detach) { out(`  Logs: ${fmt.dim(path.relative(process.cwd(), P.dir) + '/app-<name>.log')}   Stop with ${fmt.cyan('npx obs-kit stop')}\n`); return 0; }

  let stopping = false; const killAll = (sig) => { for (const { child } of children) { try { child.kill(sig); } catch { /* gone */ } } };
  const onSig = (sig) => () => { if (stopping) { killAll('SIGKILL'); return; } stopping = true; killAll(sig); setTimeout(() => killAll('SIGKILL'), 6000).unref(); };
  process.on('SIGINT', onSig('SIGINT')); process.on('SIGTERM', onSig('SIGTERM'));
  const codes = await Promise.all(children.map(({ svc, child }) => new Promise((res) => child.on('exit', (code, sig) => { if (!stopping) out(`\n  ${code === 0 ? sym.ok : sym.warn}  ${fmt.bold(svc.name)} exited ${sig ? `(signal ${sig})` : `with code ${code}`}`); res(code ?? 0); }))));
  const st = U.readJson(P.state, {}); U.writeJson(P.state, { ...st, cliPid: undefined, apps: (st.apps || []).filter((a) => !apps.some((n) => n.pid === a.pid)) });
  if (viewer) out(`\n  ${fmt.dim('Viewer still running. Open it with `npx obs-kit dashboard`, stop it with `npx obs-kit stop`.')}\n`);
  return stopping ? 0 : Math.max(...codes);
}

module.exports = { start, buildAppEnv, resolveServices, ensureViewer };
