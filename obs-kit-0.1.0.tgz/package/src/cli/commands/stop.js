'use strict';
const U = require('../util');
const { fmt, sym, out } = U;

async function stop({ flags }) {
  const root = U.findRoot(process.cwd()); const P = U.paths(root); const state = U.readJson(P.state, {});
  const apps = state.apps || []; const viewer = state.viewer; let did = 0;

  // Apps started in the foreground are children of an `obs-kit start` process: signal it and it shuts them down.
  const cli = state.cliPid && state.cliPid !== process.pid && U.pidMatches(state.cliPid, 'obs-kit') ? state.cliPid : null;
  if (cli) { try { process.kill(cli, 'SIGTERM'); out(`  ${sym.ok}  stopped foreground session ${fmt.dim('(pid ' + cli + ')')}`); did++; } catch { /* gone */ } }
  for (const a of apps) {
    if (a.mode === 'foreground') continue;
    if (!U.pidMatches(a.pid, a.command)) { out(`  ${fmt.dim('-')}  ${a.name} is not running`); continue; }
    U.killTree(a.pid, 'SIGTERM'); const gone = await U.waitFor(() => !U.isAlive(a.pid), 4000); if (!gone) U.killTree(a.pid, 'SIGKILL');
    out(`  ${sym.ok}  stopped ${fmt.bold(a.name)} ${fmt.dim('(pid ' + a.pid + ')')}`); did++;
  }
  if (viewer && !flags['keep-viewer']) {
    if (U.pidMatches(viewer.pid, 'viewer/server.js')) {
      U.killTree(viewer.pid, 'SIGTERM'); const gone = await U.waitFor(() => !U.isAlive(viewer.pid), 4000); if (!gone) U.killTree(viewer.pid, 'SIGKILL');
      out(`  ${sym.ok}  stopped viewer ${fmt.dim('(pid ' + viewer.pid + ', in-memory data discarded)')}`); did++;
    } else out(`  ${fmt.dim('-')}  viewer is not running`);
  }
  U.writeJson(P.state, flags['keep-viewer'] ? { ...state, apps: [], cliPid: undefined } : {});
  if (!did) out(`  ${fmt.dim('Nothing was running for this project.')}`);
  return 0;
}
module.exports = { stop };
