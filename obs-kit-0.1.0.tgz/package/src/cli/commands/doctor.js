'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const U = require('../util');
const { fmt, sym, out } = U;
const auth = require('../../viewer/auth');
const { resolveServices } = require('./start');

const SDK_DEPS = ['@opentelemetry/api', '@opentelemetry/api-logs', '@opentelemetry/resources', '@opentelemetry/sdk-trace-node', '@opentelemetry/sdk-trace-base', '@opentelemetry/sdk-metrics', '@opentelemetry/sdk-logs',
  '@opentelemetry/exporter-trace-otlp-http', '@opentelemetry/exporter-metrics-otlp-http', '@opentelemetry/exporter-logs-otlp-http', '@opentelemetry/instrumentation', '@opentelemetry/auto-instrumentations-node'];

async function doctor({ flags }) {
  const root = U.findRoot(process.cwd()); const P = U.paths(root); const cfg = U.loadConfig(root); const results = [];
  const rec = (status, name, detail, hint) => { results.push({ status, name, detail, hint }); if (!flags.json) { out(`  ${status === 'ok' ? sym.ok : status === 'warn' ? sym.warn : sym.bad}  ${name}${detail ? fmt.dim('  ' + detail) : ''}`); if (hint && status !== 'ok') out(`       ${fmt.dim('→ ' + hint)}`); } };
  if (!flags.json) out(`\n  ${fmt.bold('obs-kit doctor')} ${fmt.dim('v' + U.pkg.version)}\n`);

  // ---- environment & project
  const major = Number(process.versions.node.split('.')[0]);
  rec(major >= 18 ? 'ok' : 'fail', `Node.js ${process.version}`, major >= 18 ? '' : 'need >= 18', 'upgrade Node.js to 18 or newer');
  const hasCfg = fs.existsSync(P.config);
  rec(hasCfg ? 'ok' : 'warn', hasCfg ? `Config ${path.relative(process.cwd(), P.config) || U.CONFIG_NAME}` : 'No obs-kit.config.json', hasCfg ? '' : 'using defaults', 'run: npx obs-kit init');
  try {
    const services = resolveServices(root, cfg, {}, [], []);
    for (const s of services) rec(s.command ? 'ok' : 'warn', `Service "${s.name}"`, s.command ? `runs: ${s.command}` : 'no start command', s.command ? '' : 'set "command" in obs-kit.config.json or use: npx obs-kit start -- <cmd>');
  } catch (e) { rec('warn', 'Services', e.message); }

  // ---- SDK dependencies (these were never installable in some environments: be explicit)
  const missing = []; for (const d of SDK_DEPS) { try { require.resolve(d, { paths: [U.PKG_ROOT] }); } catch { missing.push(d); } }
  rec(missing.length ? 'fail' : 'ok', 'Node SDK dependencies', missing.length ? `missing: ${missing.slice(0, 3).join(', ')}${missing.length > 3 ? ` +${missing.length - 3} more` : ''}` : `${SDK_DEPS.length} OpenTelemetry packages found`, 'run: npm install obs-kit  (Node apps only; other languages use their own OpenTelemetry SDK)');

  // ---- where is telemetry going?
  const remote = process.env.OBS_ENDPOINT || cfg.endpoint; const secrets = U.readJson(P.secrets); const state = U.readJson(P.state, {}); const v = state.viewer;
  let ingest = null, uiBase = null, token = null;
  if (remote) {
    ingest = String(remote).replace(/\/$/, ''); token = process.env.OBS_TOKEN || '';
    rec('ok', 'Remote mode', ingest);
    const r = await U.request(`${ingest}/v1/traces`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: '{"resourceSpans":[]}' }).catch((e) => ({ err: e }));
    if (r.err) rec('fail', 'Reach endpoint', r.err.code || r.err.message, 'check the URL, DNS, firewall and TLS certificate');
    else if (r.status === 401 || r.status === 403) rec('fail', 'Endpoint accepted the connection but rejected the token', `HTTP ${r.status}`, 'set OBS_TOKEN to the ingest token');
    else if (r.status >= 200 && r.status < 300) rec('ok', 'Endpoint accepts telemetry', `HTTP ${r.status}`);
    else rec('fail', 'Unexpected endpoint response', `HTTP ${r.status}`, 'is this an OTLP/HTTP receiver? the path is <endpoint>/v1/traces');
  } else {
    if (!v || !U.pidMatches(v.pid, 'viewer/server.js')) { rec('fail', 'Viewer is not running', '', 'run: npx obs-kit start'); return finish(results, flags); }
    rec('ok', 'Viewer process', `pid ${v.pid}`); ingest = `http://127.0.0.1:${v.ingestPort}`; uiBase = `http://127.0.0.1:${v.uiPort}`; token = secrets && secrets.ingestToken;
    const h = await U.request(`${ingest}/healthz`).catch((e) => ({ err: e }));
    rec(h.status === 200 ? 'ok' : 'fail', `Ingest port ${v.ingestPort}`, h.status === 200 ? 'healthy' : (h.err ? h.err.code : `HTTP ${h.status}`), `see ${path.relative(process.cwd(), P.viewerLog)}`);
    const u = await U.request(`${uiBase}/`).catch((e) => ({ err: e })); rec(u.status === 200 ? 'ok' : 'fail', `Dashboard port ${v.uiPort}`, u.status === 200 ? 'serving' : (u.err ? u.err.code : `HTTP ${u.status}`));
    const noTok = await U.request(`${ingest}/v1/traces`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }).catch(() => ({}));
    rec(noTok.status === 401 ? 'ok' : 'fail', 'Ingest rejects requests without a token', noTok.status ? `HTTP ${noTok.status}` : 'no response', 'the viewer must require the bearer token');
    const cookie = secrets && `obs_session=${auth.makeSessions(secrets.sessionSecret, 60000).issue()}`;
    const ses = cookie && await U.request(`${uiBase}/api/session`, { headers: { Cookie: cookie } }).catch(() => ({}));
    rec(ses && ses.json && ses.json.authed ? 'ok' : 'fail', 'Owner session accepted by dashboard', '', 'secrets in .obs-kit/ no longer match the running viewer: run npx obs-kit stop && npx obs-kit start');
    if (!(ses && ses.json && ses.json.authed)) return finish(results, flags);

    // ---- end-to-end probe 1: raw OTLP (proves viewer pipeline, independent of any SDK)
    const now = Date.now(); const ns = (ms) => String(BigInt(Math.round(ms)) * 1000000n); const res = { attributes: [{ key: 'service.name', value: { stringValue: 'obs-kit-doctor' } }] };
    const tid = crypto.randomBytes(16).toString('hex'); const H = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
    const sends = await Promise.all([
      U.request(`${ingest}/v1/traces`, { method: 'POST', headers: H, body: JSON.stringify({ resourceSpans: [{ resource: res, scopeSpans: [{ spans: [{ traceId: tid, spanId: crypto.randomBytes(8).toString('hex'), name: 'doctor probe', kind: 2, startTimeUnixNano: ns(now - 20), endTimeUnixNano: ns(now), status: { code: 1 } }] }] }] }) }),
      U.request(`${ingest}/v1/logs`, { method: 'POST', headers: H, body: JSON.stringify({ resourceLogs: [{ resource: res, scopeLogs: [{ logRecords: [{ timeUnixNano: ns(now), severityText: 'INFO', body: { stringValue: 'doctor probe' }, traceId: tid }] }] }] }) }),
      U.request(`${ingest}/v1/metrics`, { method: 'POST', headers: H, body: JSON.stringify({ resourceMetrics: [{ resource: res, scopeMetrics: [{ metrics: [{ name: 'doctor.probe', unit: '1', gauge: { dataPoints: [{ timeUnixNano: ns(now), asDouble: 1 }] } }] }] }] }) }),
    ]).catch(() => []);
    rec(sends.length === 3 && sends.every((r) => r.status === 200) ? 'ok' : 'fail', 'Viewer accepts traces, logs and metrics', sends.map((r) => r.status).join('/'), 'ingest token mismatch or viewer error: see viewer.log');
    const detail = async (name) => { const r = await U.request(`${uiBase}/api/service/${encodeURIComponent(name)}?window=5m`, { headers: { Cookie: cookie } }).catch(() => ({})); return r.json; };
    const d1 = await detail('obs-kit-doctor'); const sig1 = d1 && d1.signals; rec(sig1 && sig1.traces && sig1.logs && sig1.metrics ? 'ok' : 'fail', 'Probe data visible in the dashboard API', sig1 ? ['traces', 'logs', 'metrics'].map((k) => `${k}:${sig1[k] ? 'yes' : 'NO'}`).join(' ') : 'service not found');

    // ---- end-to-end probe 2: the real Node SDK in a child process (catches OpenTelemetry version / wiring problems)
    if (!missing.length) {
      const sdkDir = path.join(U.PKG_ROOT, 'src', 'sdk');
      const script = `const d=${JSON.stringify(sdkDir)};const sdk=require(d+'/index.js');const p=sdk.initObservability({serviceName:'obs-kit-doctor-sdk',serviceType:'http-api',captureConsole:true});if(!p){process.exit(3)}
        const api=require(require.resolve('@opentelemetry/api',{paths:[d]}));api.trace.getTracer('doctor').startActiveSpan('doctor-sdk-check',(s)=>{console.log('obs-kit doctor sdk log');s.end();});
        sdk.flushObservability().then(()=>setTimeout(()=>process.exit(0),300));`;
      const child = spawnSync(process.execPath, ['-e', script], { env: { ...process.env, NODE_OPTIONS: '', OBS_ENDPOINT: ingest, OBS_TOKEN: token }, encoding: 'utf8', timeout: 20000 });
      if (child.status !== 0) rec('fail', 'Node SDK starts and exports', (child.stderr || '').split('\n').find((l) => l.includes('obs-kit')) || `exit ${child.status}`, 'run with OBS_DEBUG=1 for details; reinstall dependencies: npm install obs-kit');
      else {
        let sig = null; await U.waitFor(async () => { const d = await detail('obs-kit-doctor-sdk'); sig = d && d.signals; return sig && sig.traces && sig.logs && sig.metrics; }, 6000, 300);
        const got = ['traces', 'logs', 'metrics'].map((k) => `${k}:${sig && sig[k] ? 'yes' : 'NO'}`);
        rec(sig && sig.traces && sig.logs && sig.metrics ? 'ok' : 'fail', 'Node SDK → viewer, all three signals', got.join(' '), 'the SDK ran but a signal did not arrive: set OBS_DEBUG=1 and re-run, then report the output');
      }
    } else rec('warn', 'Node SDK end-to-end probe skipped', 'dependencies missing');
    for (const n of ['obs-kit-doctor', 'obs-kit-doctor-sdk']) await U.request(`${uiBase}/api/forget?service=${n}`, { method: 'POST', headers: { Cookie: cookie } }).catch(() => {});
  }
  return finish(results, flags);
}

function finish(results, flags) {
  const n = (s) => results.filter((r) => r.status === s).length;
  if (flags.json) out(JSON.stringify({ ok: n('fail') === 0, results }, null, 2));
  else out(`\n  ${n('ok')} passed${n('warn') ? `, ${fmt.yellow(n('warn') + ' warning' + (n('warn') > 1 ? 's' : ''))}` : ''}${n('fail') ? `, ${fmt.red(n('fail') + ' failed')}` : ''}\n`);
  return n('fail') ? 1 : 0;
}
module.exports = { doctor };
