'use strict';
const U = require('../util');
const { fmt, sym, out, CliError } = U;
const auth = require('../../viewer/auth');

async function dashboard({ flags }) {
  const root = U.findRoot(process.cwd()); const P = U.paths(root); const v = (U.readJson(P.state, {}) || {}).viewer; const secrets = U.readJson(P.secrets);
  if (!v || !secrets || !U.pidMatches(v.pid, 'viewer/server.js')) throw new CliError('The viewer is not running for this project.', 'Start it with: npx obs-kit start');
  const alive = await U.request(`http://127.0.0.1:${v.ingestPort}/healthz`, { timeout: 1500 }).catch(() => null);
  if (!alive || alive.status !== 200) throw new CliError('The viewer process exists but is not answering.', `Check ${U.paths(root).viewerLog}`);
  const host = v.host === '0.0.0.0' ? 'localhost' : v.host; const base = `http://${host}:${v.uiPort}`;
  const link = `${base}/auth/link?t=${encodeURIComponent(auth.makeLinks(secrets.sessionSecret).issue())}`;
  if (flags.json) { out(JSON.stringify({ url: base + '/', signInUrl: link, ingest: `http://127.0.0.1:${v.ingestPort}` })); return 0; }
  out(`\n  ${fmt.bold('obs-kit dashboard')}\n`);
  out(`  ${sym.arrow}  ${fmt.bold('Local:   ')} ${fmt.cyan(base + '/')}`);
  out(`  ${sym.arrow}  ${fmt.bold('Sign in: ')} ${fmt.cyan(link)}`);
  out(`     ${fmt.dim('one-time link, valid for 5 minutes')}`);
  if (flags.password) out(`  ${sym.arrow}  ${fmt.bold('Password:')} ${secrets.ownerPassword}`); else out(`     ${fmt.dim('Prefer a password? run with --password')}`);
  out(`  ${sym.arrow}  ${fmt.bold('Ingest:  ')} ${fmt.dim(`http://127.0.0.1:${v.ingestPort} (OTLP/HTTP)`)}\n`);
  if (flags.open) U.openBrowser(link);
  return 0;
}
module.exports = { dashboard };
