'use strict';
const U = require('./util');
const { fmt, out, CliError } = U;

const COMMANDS = {
  init: { desc: 'Configure obs-kit in this project (creates obs-kit.config.json)', run: () => require('./commands/init').init },
  start: { desc: 'Start the local viewer and your instrumented app(s)', run: () => require('./commands/start').start },
  stop: { desc: 'Stop the local viewer and any managed processes', run: () => require('./commands/stop').stop },
  doctor: { desc: 'Check configuration, connectivity and the full telemetry path', run: () => require('./commands/doctor').doctor },
  dashboard: { desc: 'Print the dashboard URL (and a one-time sign-in link)', run: () => require('./commands/dashboard').dashboard },
};

function help() {
  out(`
  ${fmt.bold('obs-kit')} ${fmt.dim('v' + U.pkg.version)}  traces, metrics and logs for any service. No database, owner-only access.

  ${fmt.bold('Usage')}  npx obs-kit <command> [options]

  ${fmt.bold('Commands')}
${Object.entries(COMMANDS).map(([k, v]) => `    ${fmt.cyan(k.padEnd(10))} ${v.desc}`).join('\n')}

  ${fmt.bold('Examples')}
    npx obs-kit init                          set up this project
    npx obs-kit start                         run viewer + app (command from config / package.json)
    npx obs-kit start -- python app.py        instrument any command
    npx obs-kit start --detach                run in the background, then: obs-kit stop
    npx obs-kit start --viewer-only --host 0.0.0.0     host a viewer for other machines
    npx obs-kit start --endpoint https://viewer:4320 --token $T   send to an existing viewer/collector
    npx obs-kit dashboard --open              open the dashboard signed in

  ${fmt.bold('Options')}
    --name <n>  --command <c>  --ui-port <p>  --ingest-port <p>  --host <h>  --detach  --force  --json  -h  -v
`);
}

async function main(argv) {
  const { flags, rest, passthrough } = U.parseArgs(argv);
  const cmd = rest.shift();
  if (flags.version || cmd === 'version') { out(U.pkg.version); return 0; }
  if (!cmd || flags.help || cmd === 'help') { help(); return cmd && !COMMANDS[cmd] && cmd !== 'help' ? 1 : 0; }
  if (!COMMANDS[cmd]) { out(`  ${fmt.red('Unknown command:')} ${cmd}`); help(); return 1; }
  try { return (await COMMANDS[cmd].run()({ flags, rest, passthrough })) || 0; }
  catch (e) {
    if (e instanceof CliError) { console.error(`\n  ${fmt.red('✗')} ${e.message}`); if (e.hint) console.error(`    ${fmt.dim(e.hint)}`); console.error(''); return 1; }
    console.error(`\n  ${fmt.red('✗ unexpected error:')} ${e && e.stack || e}\n`); return 2;
  }
}
module.exports = { main, COMMANDS };
