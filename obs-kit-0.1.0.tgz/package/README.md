# obs-kit

Traces, metrics and logs for **any service** with one CLI. No database, no cloud account, and the dashboard is **owner-only**.

```bash
npx obs-kit init        # once per project
npx obs-kit start       # runs the viewer + your app with telemetry switched on
npx obs-kit dashboard   # prints the dashboard URL and a one-click sign-in link
```

```
  obs-kit v0.1.0

  ➜  Dashboard: http://127.0.0.1:7800/
  ➜  Ingest:    http://127.0.0.1:4320  (OTLP/HTTP, bearer token required)
```

## Commands

| Command | What it does |
|---|---|
| `npx obs-kit init` | Detects your project (name, start command, language; or a multi-service workspace), writes `obs-kit.config.json` (no secrets, safe to commit), generates local credentials in `.obs-kit/` (git-ignored, mode 600). `--install` also runs `npm install obs-kit`. |
| `npx obs-kit start` | Starts the local viewer in the background, then runs your app with the SDK injected. **No code changes**: Node apps get `--require obs-kit/register`; every other language gets the standard `OTEL_*` variables. Reuses a running viewer. |
| `npx obs-kit stop` | Stops the viewer and every process obs-kit started (also works from a second terminal). |
| `npx obs-kit doctor` | Checks Node version, config, SDK dependencies, viewer, ports, auth, and **sends real test data through the full path**. Exits 1 on failure; `--json` for CI. |
| `npx obs-kit dashboard` | Prints the dashboard URL plus a **single-use sign-in link** (valid 5 min). `--open` opens it, `--password` also prints the password, `--json` for scripts. |

Useful variants:

```bash
npx obs-kit start -- python app.py                 # instrument any command
npx obs-kit start --detach                         # background; stop with `obs-kit stop`
npx obs-kit start orders payments                  # only some services of a workspace
npx obs-kit start --viewer-only --host 0.0.0.0     # host a viewer for other machines (put TLS/VPN in front)
npx obs-kit start --endpoint https://viewer:4320 --token $OBS_TOKEN   # send to an existing viewer/collector
```

## Microservices

Run `init` in the folder that contains your services. If it finds two or more projects it writes a `services` list, and `start` runs them all together with prefixed output and **one shared dashboard**:

```
orders   | listening on 3001
payments | listening on 3002
```

Trace context is propagated between services automatically (W3C `traceparent` over HTTP/gRPC/Kafka etc.), so a call from `orders` to `payments` is one trace and appears on the **Service map**. Give every service a unique name.

Already deployed (Docker/Kubernetes/VMs)? Run one viewer (`start --viewer-only`, or `src/viewer/server.js`, or the included `docker-compose.yml` with the hardened collector), then give each service:

```bash
OBS_ENDPOINT=https://your-viewer:4320  OBS_TOKEN=...  node -r obs-kit/register server.js
```

## Any language

The viewer speaks standard **OTLP/HTTP in both JSON and protobuf**, so any OpenTelemetry SDK can send to it directly.

| Language | How |
|---|---|
| Node.js | Nothing to do under `obs-kit start`. In production: `npm i obs-kit`, then `node -r obs-kit/register app.js` or `require('obs-kit/sdk').initObservability()` first. ESM apps get an extra `--import` hook automatically. |
| Python | `pip install opentelemetry-distro opentelemetry-exporter-otlp`, then `npx obs-kit start -- opentelemetry-instrument python app.py` |
| Java | `npx obs-kit start -- java -javaagent:opentelemetry-javaagent.jar -jar app.jar` |
| Go / .NET / others | Use the OTLP **HTTP** exporters; they read the `OTEL_*` variables obs-kit sets. |

gRPC OTLP is not accepted by the viewer; put an OpenTelemetry Collector in front (`collector/otel-collector.yaml`).

## What you get

Overview (traffic, latency p50/p95/p99, error rate, per-service table), **per-service pages** (endpoints, dependencies including databases and external APIs, runtime CPU/memory/event-loop, errors, logs), service map, trace waterfall with span attributes and correlated logs, log search, and a metrics explorer.

Request rate, error rate and latency percentiles are **derived from traces**, so even a single service shows data if its metrics pipeline is empty. Every service shows which of **T**races / **M**etrics / **L**ogs it has sent, with a note and a fix when one is missing.

## Why a lone service used to show nothing

Root causes found and fixed:

- **Metrics only arrived after a full 15–30 s interval**, and short runs exited before the first export. Now the first flush happens ~2 s after start, the interval is 10 s, and everything is flushed on exit/SIGINT/SIGTERM.
- **Counters and histograms were shown raw**, so a single point looked like "nothing". Counters become per-second rates, histograms become interval mean and p95, and restarts are handled.
- **Nothing reported *what* was missing.** The dashboard and `doctor` now name the missing signal.
- **The SDK depended on one all-in-one OpenTelemetry class** whose option names changed between releases, which can silently drop signals. Providers are now built explicitly and version-pinned.
- **Redaction mutated frozen objects and could silently fail.** It now works on copies.

If something is still empty: `npx obs-kit doctor`, then run your app with `OBS_DEBUG=1`.

## Security

- Ingest and dashboard are separate listeners, both on `127.0.0.1` by default. Ingest requires a bearer token (constant-time compare) and optionally a client certificate (mTLS).
- Dashboard: scrypt-hashed owner password or single-use link; HMAC-signed `HttpOnly` `SameSite=Strict` cookie; login throttling; strict CSP with no inline script or style; telemetry rendered only via `textContent`.
- The SDK redacts secrets (auth headers, cookies, tokens, card numbers, JWTs, secrets in URLs) before export; the collector config adds a second pass.
- Data lives only in memory (bounded; 1 h default). **Restart = data gone.**
- Secrets live in `.obs-kit/secrets.json` (mode 600, git-ignored). Sessions are stateless: rotate `sessionSecret` to invalidate all.
- Remote access: SSH tunnel or VPN. For non-local hosting use `docker-compose.yml` (mTLS between collector and viewer) and a TLS-terminating proxy.

## Verification status

| Part | Status |
|---|---|
| Viewer: auth, ingest (JSON + protobuf), store, aggregation, API | Tested (`npm test`) |
| Protobuf decoder | Tested by round-trip against an encoder written from the OTLP schema. **Not yet validated against a real Python/Java/Go exporter.** |
| Dashboard UI | Tested in headless Chromium (`npm run test:ui`, needs Playwright): all pages, tooltips, mobile width, no console or CSP errors |
| CLI (`init/start/stop/doctor/dashboard`, workspace, remote mode, detach) | Tested end to end (`npm test`) with a stand-in service that uses only `OTEL_*` variables |
| **Node SDK ↔ real OpenTelemetry packages** (`src/sdk/index.js`) | **Not run.** The build sandbox could not install npm packages, so the SDK was written against the OTel JS 2.x / 0.2xx APIs and only syntax-checked. Run `npx obs-kit doctor` after `npm install`: its last check exercises the real SDK and reports exactly which signal fails. |
| Collector YAML, docker-compose | Parse as YAML; not run against a real collector |
| Dependency version ranges in `package.json` | Written from knowledge of the OTel release lines, **not resolved against the registry**; run `npm install` and `npm test`, adjust if a range is wrong |

## Limits

- Single owner account and one tenant per viewer.
- Histograms: mean and p95 only; exponential histograms use count/sum only.
- Data is lost on viewer restart by design. For history, forward from the collector to a store of your choice.
- Only a Node SDK wrapper exists; other languages use their own OpenTelemetry SDK.

## Publishing to npm

```bash
npm view obs-kit            # the name may be taken; if so, rename ("name" in package.json) or use a scope: @you/obs-kit
npm install && npm test     # real run, including `doctor` against the real SDK
npm login                   # enable 2FA on your account
npm publish --access public # add --provenance when publishing from CI
```
`prepublishOnly` runs the tests. `npm pack --dry-run` lists exactly what ships (30 files, ~60 kB; no tests, no secrets). For a scoped name, users run `npx @you/obs-kit …`, or add a `bin` alias; the unscoped `npx obs-kit` requires the unscoped name.
